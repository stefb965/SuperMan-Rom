    /*+touch event feature+*/
    var prevTouches = null;
    var isImageMoveable = false;
    var isImageSelected = false;
    var isExceptionImageSelected = false;
    var isMoved = false;
    var prevSelectedImageObject = null, selectedImageObject = null;

    var mHandlerIconWidth = 13;
    var mTouchedHandlerIconWidth = 15;
    
	var timer, timePressed = 0;
	
	var mTmpImgID = "";
	var mTmpImgSrc = "";

    function setTouchListenerAtImage(value) {
        var img = document.getElementById(value);

        img.addEventListener("touchstart", imageTouchDown, false);
        img.addEventListener("touchend", imageTouchUp, false);
        img.addEventListener("touchcancel", imageTouchCancel, false);
        img.addEventListener("touchmove", imageTouchMove, false);

        console.log("contentID - " + value + " : initialized.");
    }

    function documentTouchDown(evt) {
        console.log("Document - touch start.");
        var result = stackForTracingEvent.push("touchstart");

        if(isImageSelected) {
            isExceptionImageSelected = true;
            window.HtmlEditingView.jsExceptionOfImageSelection(isExceptionImageSelected);
        }
        selectTextTouchDown(evt);
    }
    
    function documentTouchUp(evt) {
        console.log("Document - touch end.");
        if( 0 != stackForTracingEvent.length ) {
            var result = stackForTracingEvent.push("touchend");
        }
        
        if(isImageMoveable) {
            console.log("Document - touch end - isImageMoveable");
            var touch = evt.changedTouches[0]; 
            var sel = document.getSelection();
            var range = document.createRange();
            
            var caretPosition = document.caretRangeFromPoint(touch.clientX, touch.clientY);
            if( null!= caretPosition && undefined != caretPosition.startContainer ) {
                deselectImage();
                var imgStr = selectedImageObject.outerHTML;
                var elementId = selectedImageObject.id;
                range.selectNode(selectedImageObject);
                sel.removeAllRanges();
                sel.addRange(range);
                document.execCommand("delete");

                range = document.createRange();
                range.setStart(caretPosition.startContainer, caretPosition.startOffset);
                range.setEnd(caretPosition.startContainer, caretPosition.startOffset);
                sel.removeAllRanges();
                sel.addRange(range);
                document.execCommand("insertHTML", false, imgStr);
                setTouchListenerAtImage(elementId);

                isImageMoveable = false;
                window.HtmlEditingView.jsCanImageMove(false);
                prevSelectedImageObject = null;
                selectedImageObject = null;
            } else {
                isImageMoveable = false;
                window.HtmlEditingView.jsCanImageMove(false);
                document.body.blur();
            }
        }
        
        else if(isImageSelected) {
            console.log("Document - touch end - isImageSelected");
            deselectImage();
            isImageMoveable = false;
            prevSelectedImageObject = null;
            selectedImageObject = null;
            window.HtmlEditingView.jsCanImageMove(false);
        }
        
        if(isExceptionImageSelected) {
            isExceptionImageSelected = false;
            window.HtmlEditingView.jsExceptionOfImageSelection(isExceptionImageSelected);
        }
        isMoved = false;
    }

    function documentTouchMove(evt) {
        console.log("Document - touch move.");
        if(isImageSelected && isImageMoveable){
            var touch = evt.changedTouches[0]; 

            if( touch.clientX >= selectedImageObject.offsetLeft
                    && touch.clientX <= (selectedImageObject.offsetLeft + selectedImageObject.offsetWidth )
                    && touch.clientY >= selectedImageObject.offsetTop
                    && touch.clientY <= (selectedImageObject.offsetTop + selectedImageObject.offsetHeight) ) {
            } else {
                console.log("need to show a cursor!");

                var range = document.createRange();
                console.log("touch.clientX, touch.clientY = " + touch.clientX + ", " + touch.clientY);
                var caretPosition = document.caretRangeFromPoint(touch.clientX, touch.clientY);
            
                if( null!= caretPosition && undefined != caretPosition.startContainer  ) {
                    range.setStart(caretPosition.startContainer, caretPosition.startOffset);
                    range.setEnd(caretPosition.startContainer, caretPosition.startOffset);
            
                    var sel = document.getSelection();
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
            }
            
            isMoved = true;
        }
    }

    function documentTouchCancel(evt) {
        console.log("Document - touch cancel.");
    }

    function handlerTouchDown(evt) {
        console.log("Handler - touch start.");

        var id = this.id;
        var handlerIcon = document.getElementById(id);
        changeImageHandlerWidth(id , true);

        evt.preventDefault();
        evt.stopPropagation();

        prevTouches = evt.changedTouches[0];
        
        window.HtmlEditingView.jsIsResizingHandlerPressed(true);

        if(isExceptionImageSelected) {
            isExceptionImageSelected = false;
            window.HtmlEditingView.jsExceptionOfImageSelection(isExceptionImageSelected);
        }
    }

    function handlerTouchUp(evt) {
        console.log("Handler - touch end.");

        var id = this.id;
        var handlerIcon = document.getElementById(id);
        changeImageHandlerWidth(id , false);

        evt.preventDefault();
        evt.stopPropagation();

        window.HtmlEditingView.jsIsResizingHandlerPressed(false);

        /*+ hovering feature (give selectedImagePosition) +*/
        if( !curSelectedImage )
        {
            console.log("handlerTouchUp curSelectedImage is null!");
            return;
        }

        var left = curSelectedImage.offsetLeft;
        var top = curSelectedImage.offsetTop;

        var parentObj = curSelectedImage.offsetParent;
        while( parentObj ) {
            left += parentObj.offsetLeft;
            top += parentObj.offsetTop;
            parentObj = parentObj.offsetParent;
        }

        var right = left + curSelectedImage.offsetWidth;
        var bottom = top + curSelectedImage.offsetHeight;
           
        var imageRect = new Rect(left, top, right, bottom);
        var jsonResult = JSON.stringify(imageRect);
        window.HtmlEditingView.jsSelectedImagePositionChanged(jsonResult);
        /*- hovering feature -*/
    }

    function handlerTouchMove(evt) {
        console.log("Handler - touch move.");
        evt.preventDefault();
        evt.stopPropagation();

        var id = this.id;
        var currentTouches = evt.changedTouches[0];

        var changePointX = 0, changePointY = 0;
        var type = parseInt(id.charAt(id.length-1));
        
        if(currentTouches.clientX < 0 || currentTouches.clientY < 0)
            return;

        switch (type) {
            case 0 :
                console.log("0");
                changePointX = prevTouches.clientX - currentTouches.clientX;
                changePointY = prevTouches.clientY - currentTouches.clientY;
                if(Math.abs(changePointX) > Math.abs(changePointY))
                    changePointY = (changePointX * selectedImageObject.height) / selectedImageObject.width;
                else
                    changePointX = (selectedImageObject.width * changePointY) / selectedImageObject.height;
                break;
            case 1 :
                console.log("1");
                changePointX = currentTouches.clientX - prevTouches.clientX;
                changePointY = prevTouches.clientY - currentTouches.clientY;
                
                if(Math.abs(changePointX) > Math.abs(changePointY))
                    changePointY = (changePointX * selectedImageObject.height) / selectedImageObject.width;
                else
                    changePointX = (selectedImageObject.width * changePointY) / selectedImageObject.height;
                break;
            case 2 :
                console.log("2");
                changePointX = prevTouches.clientX - currentTouches.clientX;
                changePointY = currentTouches.clientY - prevTouches.clientY;
                
                if(Math.abs(changePointX) > Math.abs(changePointY))
                    changePointY = (changePointX * selectedImageObject.height) / selectedImageObject.width;
                else
                    changePointX = (selectedImageObject.width * changePointY) / selectedImageObject.height;
                break;
            case 3 :
                console.log("3");
                changePointX = currentTouches.clientX - prevTouches.clientX;
                changePointY = currentTouches.clientY - prevTouches.clientY;
                
                if(Math.abs(changePointX) > Math.abs(changePointY))
                    changePointY = (changePointX * selectedImageObject.height) / selectedImageObject.width;
                else
                    changePointX = (selectedImageObject.width * changePointY) / selectedImageObject.height;
                break;
            case 4 :
                console.log("4");
                changePointX = prevTouches.clientX - currentTouches.clientX;
                break;
            case 5 :
                console.log("5");
                changePointX = currentTouches.clientX - prevTouches.clientX;
                break;
            case 6 :
                console.log("6");
                changePointY = prevTouches.clientY - currentTouches.clientY;
                break;
            case 7 :
                console.log("7");
                changePointY = currentTouches.clientY - prevTouches.clientY;
                break;
            default :
                console.log("default");
                changePointX = 0, changePointY = 0;
                break;
        }

        if(changePointX != 0 || changePointY != 0) {
            // updateOutline
            if ((changePointX < 0 && mTouchedHandlerIconWidth > selectedImageObject.width + changePointX) ||
                (changePointY < 0 && mTouchedHandlerIconWidth > selectedImageObject.height + changePointY)) {
                //console.log("!!!image width = " + selectedImageObject.width + " " + mTouchedHandlerIconWidth + "  screen width = " + window.screen.width + " !!!");
                return;
            }

            if( changePointX != 0 ) {
                if( window.outerWidth < selectedImageObject.offsetLeft + selectedImageObject.width + changePointX + (mTouchedHandlerIconWidth - 1) / 2) {
            	    if(window.outerWidth < selectedImageObject.width && changePointX < 0)
            	        selectedImageObject.width = selectedImageObject.width+changePointX;
                    else
            	        return;
                } else {
                    selectedImageObject.width = selectedImageObject.width+changePointX;
                }
            }
                
            selectedImageObject.height = selectedImageObject.height+changePointY;

            updateImageHandler();
        }
        prevTouches = currentTouches;
    }

    function handlerTouchCancel(evt) {
        console.log("Handler - touch cancel.");

        var id = this.id;
        var handlerIcon = document.getElementById(id);
        changeImageHandlerWidth(id , false);

        evt.preventDefault();
        evt.stopPropagation();

        window.HtmlEditingView.jsIsResizingHandlerPressed(false);
    }


    function startClickChecker(){
        timePressed = 0;
        timer = setInterval(function(){
            timePressed += 100;
            if (timePressed > 1000){
            	if (mTmpImgSrc != "" && mTmpImgID != "" ) {
            		window.HtmlEditingView.jsAdditionalProcessingForImage(mTmpImgSrc, mTmpImgID);
            	}
            	mTmpImgID = "";
            	mTmpImgSrc = "";
            	clearInterval(timer);
            }
        }, 100);
    }
    
    function endClickChecker(){
    	var result = "";
        if(timePressed < 300){
        	console.log("endClickChecker - click");
            result = "click";
        } else {
        	console.log("endClickChecker - longclick");
            result = "longclick";
        }
        clearInterval(timer);
        return result;
    }

    function imageTouchDown(evt) {
        console.log("touch start.");
        
        startClickChecker();
        
        evt.stopPropagation();
        
        if(isImageSelected) {
            evt.preventDefault();

            if( this.id == prevSelectedImageObject.id) {
                isImageMoveable = true;
                window.HtmlEditingView.jsCanImageMove(true);
            }
        } else {
        	mTmpImgID = this.id;
        	mTmpImgSrc = this.src;
        }

        //To prevent the default action(Text or content selection) for long-press.
        this.style.setProperty("-webkit-user-select", "none");
        this.style.setProperty("-webkit-user-modify", "read-only");
    }

    function imageTouchUp(evt) {
        console.log("touch end.");
        
        // The properties SHOULD be removed when touch up or cancel event occurs because it can causes a unexpected issue.
        this.style.removeProperty("-webkit-user-select");
        this.style.removeProperty("-webkit-user-modify");

    	mTmpImgID = "";
    	mTmpImgSrc = "";
    	
        var clickOrlongclick = endClickChecker();
        if (clickOrlongclick == "click" ){
            isMoved = false;
        } else if(clickOrlongclick == "longclick"){
        }
        
        if( isImageSelected ) {
            evt.preventDefault();
        }
        
        console.log("image id : " + this.id);

        if(!isImageMoveable) {
            console.log("image id : " + this.id);
            console.log("isImageMoveable : " + isImageMoveable);
            console.log("isImageSelected : " + isImageSelected);
            evt.stopPropagation();
            if(isImageSelected) {
                if(this.id == prevSelectedImageObject.id) {
                    deselectImage();
                    console.log("this.id == prevSelectedImageObject.id");
                    prevSelectedImageObject = null;
                    selectedImageObject = null;
                    isImageMoveable = false;
                    window.HtmlEditingView.jsCanImageMove(false);
                }
                else {
                    console.log("this.id != prevSelectedImageObject.id");
                    deselectImage();
                    prevSelectedImageObject = this;
                    selectedImageObject = this;
                    selectImage(selectedImageObject);
                }
            }
            else {
                console.log("no selected image");
                SelectionOfSelectedPoint = evt.changedTouches[0];
                prevSelectedImageObject = this;
                selectedImageObject = this;
                selectImage(selectedImageObject);
            }
       } 
       else 
       {
           if (!isMoved)
           {
               if(selectedImageObject != null)
               {
                   if(isImageSelected) {
                       if(this.id == prevSelectedImageObject.id) {
//                           window.HtmlEditingView.jsAdditionalProcessingForImage(selectedImageObject.src, selectedImageObject.id);
                           deselectImage();
                           console.log("this.id == prevSelectedImageObject.id");
                           prevSelectedImageObject = null;
                           selectedImageObject = null;
                           isImageMoveable = false;
                           window.HtmlEditingView.jsCanImageMove(false);
                       }
                       else {
                           console.log("this.id != prevSelectedImageObject.id");
                           deselectImage();
                           prevSelectedImageObject = this;
                           selectedImageObject = this;
                           selectImage(selectedImageObject);
                       }
                   }
                }
       	    }
       	}
    }

    function imageTouchMove(evt) {
        console.log("touch move.");
        if( isImageSelected ) {
            evt.preventDefault();
        } else {
            evt.stopPropagation();
        }
    }

    function imageTouchCancel(evt) {
        // The properties SHOULD be removed when touch up or cancel event occurs because it can causes a unexpected issue.
        this.style.removeProperty("-webkit-user-select");
        this.style.removeProperty("-webkit-user-modify");

        console.log("touch cancel.");
        var clickOrlongclick = endClickChecker();
        if(clickOrlongclick == "longclick"){
            window.HtmlEditingView.jsAdditionalProcessingForImage(this.src, this.id);
        }
        if( isImageSelected ) {
            evt.preventDefault();
        }
        evt.stopPropagation();
        if(isMoved)
            isMoved = false;
        if(isImageMoveable) {
            isImageMoveable = false;
            window.HtmlEditingView.jsCanImageMove(false);
        }
    }
    /*-touch event feature-*/

    /*+image resize & move feature+*/
    var curSelectedImage = null;

    function selectImage(imageObject) {
        if( !imageObject  )
        {
            console.log("Object is null!");
            return;
        }
        if( !imageObject instanceof HTMLImageElement )
        {
            console.log("Object is not image!");
            return;
        }

        if(imageObject.offsetWidth == 0 || imageObject.offsetHeight == 0)
        {
            console.log("Object is Invalid image!");
            return;
        }

        curSelectedImage = imageObject;

        imageObject.style.borderStyle="solid";
        imageObject.style.borderWidth="1px";
        imageObject.style.borderColor="#f6a043";
        imageObject.style.zIndex=-1;

        var left = imageObject.offsetLeft;
        var top = imageObject.offsetTop;

        var parentObj = imageObject.offsetParent;
        while( parentObj ) {
            left += parentObj.offsetLeft;
            top += parentObj.offsetTop;
            parentObj = parentObj.offsetParent;
        }

        var right = left + imageObject.offsetWidth;
        var bottom = top + imageObject.offsetHeight;

        /*+ hovering feature (give selectedImagePosition) +*/                  
        var imageRect = new Rect(left, top, right, bottom);
        var jsonResult = JSON.stringify(imageRect);
        window.HtmlEditingView.jsSelectedImagePositionChanged(jsonResult);
        /*- hovering feature -*/  

        drawImageHandler(imageRect);

        isImageSelected = true;
        window.HtmlEditingView.jsUpdateStatusOfImageSelection(isImageSelected);

        var sel = window.getSelection();
        sel.removeAllRanges();
    }

    function changeImageHandlerWidth(id, touched) {
        var handlerIcon = document.getElementById(id);
        var handlerIconImg = handlerIcon.firstChild;

        if( true == touched ) {
            handlerIconImg.style.width = mTouchedHandlerIconWidth;
            handlerIconImg.style.height = mTouchedHandlerIconWidth;
            handlerIcon.offsetLeft = handlerIcon.offsetLeft - 1;
            handlerIcon.offsetTop = handlerIcon.offsetTop - 1;
        } else {
            handlerIconImg.style.width = mHandlerIconWidth;
            handlerIconImg.style.height = mHandlerIconWidth;
            handlerIcon.offsetLeft = handlerIcon.offsetLeft + 1;
            handlerIcon.offsetTop = handlerIcon.offsetTop + 1;
        }
    }

    function updateImageHandler() {
        if( null == selectedImageObject ) return;

        var handlerIcon = null;
        var left = selectedImageObject.offsetLeft;
        var top = selectedImageObject.offsetTop;

        var parentObj = selectedImageObject.offsetParent;
        while( parentObj ) {
            left += parentObj.offsetLeft;
            top += parentObj.offsetTop;
            parentObj = parentObj.offsetParent;
        }

        var right = left + selectedImageObject.offsetWidth;
        var bottom = top + selectedImageObject.offsetHeight;
        var lefthandDelta = (mHandlerIconWidth - 1)/2 + 5;
        var righthandDelta = (mHandlerIconWidth + 1)/2 + 5;
        
        handlerIcon = document.getElementById("imgHandler0"); 
        handlerIcon.style.left = left-lefthandDelta;
        handlerIcon.style.top = top-lefthandDelta;
        handlerIcon = document.getElementById("imgHandler1"); 
        handlerIcon.style.left = right-righthandDelta;
        handlerIcon.style.top = top-lefthandDelta;
        handlerIcon = document.getElementById("imgHandler2"); 
        handlerIcon.style.left = left-lefthandDelta;
        handlerIcon.style.top = bottom-righthandDelta;
        handlerIcon = document.getElementById("imgHandler3"); 
        handlerIcon.style.left = right-righthandDelta;
        handlerIcon.style.top = bottom-righthandDelta;
        handlerIcon = document.getElementById("imgHandler4"); 
        handlerIcon.style.left = left-lefthandDelta;
        handlerIcon.style.top = ((top+bottom)/2)-lefthandDelta;
        handlerIcon = document.getElementById("imgHandler5"); 
        handlerIcon.style.left = right-righthandDelta;
        handlerIcon.style.top = ((top+bottom)/2)-lefthandDelta;
        handlerIcon = document.getElementById("imgHandler6"); 
        handlerIcon.style.left = ((left+right)/2)-lefthandDelta;
        handlerIcon.style.top = top-lefthandDelta;
        handlerIcon = document.getElementById("imgHandler7"); 
        handlerIcon.style.left = ((left+right)/2)-lefthandDelta;
        handlerIcon.style.top = bottom-righthandDelta;
    }

    function drawImageHandler(imageRect) {
        var lefthandDelta = (mHandlerIconWidth - 1)/2 + 5;
        var righthandDelta = (mHandlerIconWidth + 1)/2 + 5;

        var handler = getImageHandler("imgHandler0");
        handler.style.left = imageRect.left - lefthandDelta;
        handler.style.top = imageRect.top - lefthandDelta;

        handler = getImageHandler("imgHandler1");
        handler.style.left = imageRect.right - righthandDelta;
        handler.style.top = imageRect.top - lefthandDelta;

        handler = getImageHandler("imgHandler2");
        handler.style.left = imageRect.left - lefthandDelta;
        handler.style.top = imageRect.bottom - righthandDelta;

        handler = getImageHandler("imgHandler3");
        handler.style.left = imageRect.right - righthandDelta;
        handler.style.top = imageRect.bottom - righthandDelta;

        handler = getImageHandler("imgHandler4");
        handler.style.left = imageRect.left - lefthandDelta;
        handler.style.top = ((imageRect.top+imageRect.bottom)/2) - lefthandDelta;

        handler = getImageHandler("imgHandler5");
        handler.style.left = imageRect.right - righthandDelta;
        handler.style.top = ((imageRect.top+imageRect.bottom)/2) - lefthandDelta;

        handler = getImageHandler("imgHandler6");
        handler.style.left = ((imageRect.left+imageRect.right)/2) - lefthandDelta;
        handler.style.top = imageRect.top - lefthandDelta;

        handler = getImageHandler("imgHandler7");
        handler.style.left = ((imageRect.left+imageRect.right)/2) - lefthandDelta;
        handler.style.top = imageRect.bottom - righthandDelta;
    }

    function getImageHandler(id) {
        var handlerIcon = document.createElement("div");
        handlerIcon.id=id;
        handlerIcon.style.position="absolute";
        handlerIcon.style.zIndex=0;
        handlerIcon.setAttribute("contentEditable", false);

        var handlerIconImg = document.createElement("div");
        handlerIconImg.style.width = mHandlerIconWidth;
        handlerIconImg.style.height = mHandlerIconWidth;
        handlerIconImg.style.display="block";
        handlerIconImg.style.margin=5;
        handlerIconImg.style.borderRadius = "50%";
        handlerIconImg.style.background = "#f6a043";
        handlerIcon.appendChild(handlerIconImg);

        if( !document.getElementById(id) ) {
            document.body.appendChild(handlerIcon);
        }

        handlerIcon.addEventListener("touchstart", handlerTouchDown, false);
        handlerIcon.addEventListener("touchend", handlerTouchUp, false);
        handlerIcon.addEventListener("touchcancel", handlerTouchCancel, false);
        handlerIcon.addEventListener("touchmove", handlerTouchMove, false);

        return handlerIcon;
    }

    function clearImageHanders() {
        for( i = 0; i < 8; i++ ) {
            var imgHandler = document.getElementById("imgHandler" + i);
            if( imgHandler ) {
                imgHandler.parentNode.removeChild(imgHandler);
            }
        }
    }

    function deselectImage() {
        if(!isImageSelected || selectedImageObject == null)
            return;
        console.log("deselectImage");

        var sel = window.getSelection();
        /* In this time, if there is a range selection or seletion, 
         * it means that a action for new selection,
         * - for example, selecting a word in the situation that there is already a image selection, etc -
         * has been already worked.
         * So, we SHOULD run the routine to set the cursor forcelly under the condition below.
        */
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("deselectImage() sel == null or 0 == sel.rangeCount");

            var range = document.createRange();
            range.setStartAfter(selectedImageObject);
            sel.removeAllRanges();
            sel.addRange(range);
        }
        
        if( curSelectedImage ) {
            curSelectedImage.removeAttribute("style");
            curSelectedImage = null;
        }
        clearImageHanders();

        isImageSelected = false;
        window.HtmlEditingView.jsUpdateStatusOfImageSelection(isImageSelected);
    }
    
    function deleteElement(elementID) {
        deselectImage();
        clearImageHanders();
        prevSelectedImageObject = null;
        selectedImageObject = null;
        isImageMoveable = false;
        var node = document.getElementById(elementID);
        var sel = document.getSelection();
        var range = document.createRange();
        range.selectNode(node);
        sel.removeAllRanges();
        sel.addRange(range);
        command('delete', false);
        window.HtmlEditingView.jsCanImageMove(false);
    }
    /*-image resize & move feature-*/
    
    /*+ hovering feature+*/  
    function Rect( left, top, right, bottom ) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }
    /*- hovering feature-*/  
