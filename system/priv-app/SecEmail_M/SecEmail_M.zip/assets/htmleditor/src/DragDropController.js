var isDragging = false;
var srcRange = null;

function startDrag() {
    console.log("startDrag() start");

    var webClipData = new Object();

    var selection = document.getSelection();
    var range = selection.getRangeAt(0);

    if (range.collapsed) {
        isDragStart = false;
    } else {
        var tempDiv = document.createElement('div');

        tempDiv.appendChild(getSelectionContents());
        webClipData.innerHTML = tempDiv.innerHTML;
        webClipData.innerText = tempDiv.innerText;

        clientRects = range.getClientRects();

        var selectionInfo = new Object();

        sPos = -1;
        ePos = -1;
        sHeight = -1;
        eHeight = -1;
        boundingRight = -1;
        boundingWidth = -1;

        for (var i = 0; i < clientRects.length; i++) {
            if (clientRects.item(i).width > 0) {
                if (sPos < 0) {
                    sPos = clientRects.item(i).left;
                    sHeight = clientRects.item(i).height;
                }

                ePos = clientRects.item(i).right;
                eHeight = clientRects.item(i).height;
            }
        }

        selectionInfo.startX = parseInt(sPos * window.devicePixelRatio);
        selectionInfo.startHeight = parseInt(sHeight * window.devicePixelRatio);
        selectionInfo.endX = parseInt(ePos * window.devicePixelRatio);
        selectionInfo.endHeight = parseInt(eHeight * window.devicePixelRatio);

        for (i = 0; i < clientRects.length; i++) {
            if ((clientRects.item(i).width > 0 && clientRects.item(i).width != document.body.offsetWidth)
                    && boundingRight < clientRects.item(i).right) {
                boundingRight = clientRects.item(i).right;
                boundingWidth = boundingRight
                        - range.getBoundingClientRect().left;
            }
        }

        if (boundingRight < 0 || boundingWidth < 0) {
            boundingRight = range.getBoundingClientRect().right;
            boundingWidth = range.getBoundingClientRect().width;
        }

        selectionInfo.boundingLeft = parseInt(range.getBoundingClientRect().left
                * window.devicePixelRatio);
        selectionInfo.boundingTop = parseInt(range.getBoundingClientRect().top
                * window.devicePixelRatio);
        selectionInfo.boundingBottom = parseInt(range.getBoundingClientRect().bottom
                * window.devicePixelRatio);
        selectionInfo.boundingHeight = parseInt(range.getBoundingClientRect().height
                * window.devicePixelRatio);
        selectionInfo.boundingRight = parseInt(boundingRight
                * window.devicePixelRatio);
        selectionInfo.boundingWidth = parseInt(boundingWidth
                * window.devicePixelRatio);
        webClipData.selectionInfo = selectionInfo;

        isDragging = true;
        srcRange = range.cloneRange();
    }
    return webClipData;
}

function getSelectionContents() {
    var selection = document.getSelection();
    var range = selection.getRangeAt(0);

    var selNode = range.commonAncestorContainer;
    var resultNode = null;

    if (selNode != null && selNode.nodeType == 3) {
        position = document.body.compareDocumentPosition(selNode.parentNode);
        if (position != 0 && (position & 8) == 0) {
            resultNode = range.cloneContents().cloneNode(true);
            selNode = selNode.parentNode;
        }
    }

    while (selNode != null && selNode.nodeType == 1) {
        var temp = selNode.cloneNode(false);
        if (resultNode != null)
            temp.appendChild(resultNode);
        else
            temp.appendChild(range.cloneContents().cloneNode(true));

        resultNode = temp;
        selNode = selNode.parentElement;

        position = document.body.compareDocumentPosition(selNode);
        if (position == 0 || (position & 8) != 0)
            break;
    }

    if (resultNode == null) {
        resultNode = range.cloneContents().cloneNode(true);
    }

    return resultNode;
}

function moveCaret(posX, posY) {
    var range = document.createRange();
    posX = posX / window.devicePixelRatio;
    posY = posY / window.devicePixelRatio;
    var caretPosition = document.caretRangeFromPoint(posX, posY);

    range.setStart(caretPosition.startContainer, caretPosition.startOffset);
    range.setEnd(caretPosition.startContainer, caretPosition.startOffset);

    var selection = document.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
}

function onDrop(isHEVData, htmlData) {
    console.log("YB >> onDrop() is HtmlEditingView data : " + isHEVData
            + ", start data : " + htmlData);

    if (isHEVData == true) {
        if (isContainedCurRange() != true) {
            removeSrcSelection();
            command('InsertHtml', htmlData);
        }
    } else {
        command('InsertHtml', htmlData);
    }

    var imgs = document.images;
    for( i=0; i<imgs.length; i++ ) {
        imgs[i].removeEventListener("touchstart", imageTouchDown);
        imgs[i].removeEventListener("touchend", imageTouchUp);
        imgs[i].removeEventListener("touchcancel", imageTouchCancel);
        imgs[i].removeEventListener("touchmove", imageTouchMove);

        imgs[i].addEventListener("touchstart", imageTouchDown, false);
        imgs[i].addEventListener("touchend", imageTouchUp, false);
        imgs[i].addEventListener("touchcancel", imageTouchCancel, false);
        imgs[i].addEventListener("touchmove", imageTouchMove, false);

        var d = new Date();
        imgs[i].id = d.getTime();
    }
}

function onDrop(dragData) {
    console.log("onDrop() htmlData [" + dragData.htmldata + "], textData ["
            + dragData.textdata + "], hevData [" + dragData.ishevdata + "]");

    var insertData;

    if (dragData.htmldata) {
        insertData = dragData.htmldata;
        if (insertData) {
            if (dragData.ishevdata && dragData.ishevdata == true)
                removeSrcSelection();
            command('InsertHtml', insertData);
        }
    } else {
        insertData = dragData.textdata;
        if (insertData) {
            if (dragData.ishevdata && dragData.ishevdata == true)
                removeSrcSelection();
            command('InsertText', insertData);
        }
    }

    var imgs = document.images;
    for( i=0; i<imgs.length; i++ ) {
        imgs[i].removeEventListener("touchstart", imageTouchDown);
        imgs[i].removeEventListener("touchend", imageTouchUp);
        imgs[i].removeEventListener("touchcancel", imageTouchCancel);
        imgs[i].removeEventListener("touchmove", imageTouchMove);

        imgs[i].addEventListener("touchstart", imageTouchDown, false);
        imgs[i].addEventListener("touchend", imageTouchUp, false);
        imgs[i].addEventListener("touchcancel", imageTouchCancel, false);
        imgs[i].addEventListener("touchmove", imageTouchMove, false);

        var d = new Date();
        imgs[i].id = d.getTime();
    }
}

function isContainedCurRange() {
    if (srcRange == null)
        return false;

    var selection = document.getSelection();
    var curRange = selection.getRangeAt(0);

    if (curRange.compareBoundaryPoints(Range.START_TO_START, srcRange) > -1) {
        if (curRange.compareBoundaryPoints(Range.END_TO_END, srcRange) < 1) {
            return true;
        }
    }
    return false;
}

function removeSrcSelection() {
    if (srcRange == null)
        return;

    var selection = document.getSelection();

    var destRange = selection.getRangeAt(0).cloneRange();

    selection.removeAllRanges();
    selection.addRange(srcRange);

    command('delete');

    selection.removeAllRanges();
    selection.addRange(destRange);
}

function endDrag() {
    console.log("endDrag() start");

    isDragging = false;
    srcRange = null;
}

function selectTextTouchDown(evt) {
    if (!(window.getSelection().rangeCount > 0))
        return;
    var cursorState = new Object(), range = window.getSelection().getRangeAt(0);
    cursorState.iscollapsed = range.collapsed;
    cursorState.touchSelectionText = false;

    if (cursorState.iscollapsed == false) {
        var list = evt.targetTouches;
        console.log("selectTextTouchDown() evt X : " + list.item(0).screenX
                + ", Y : " + list.item(0).screenY);
        if (list.length == 1) {
            var clientRects = range.getClientRects();
            for (var i = 0; i < clientRects.length; i++) {
                if (clientRects.item(i).width != document.body.offsetWidth) {
                    if (clientRects.item(i).top < list.item(0).clientY
                            && clientRects.item(i).bottom > list.item(0).clientY) {
                        if (clientRects.item(i).left < list.item(0).clientX
                                && clientRects.item(i).right > list.item(0).clientX) {
                            cursorState.touchSelectionText = true;
                        }
                    }
                }
            }
        }
    } else {
//        var list = evt.targetTouches;
    }

    //interface
    window.HtmlEditingView.jsCursorState(JSON.stringify(cursorState));
}