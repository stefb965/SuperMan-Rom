    var mMaxBodyHtmlLen = 100000;
    var _timerid = null;

    function load() {
        window.document.body.style.wordWrap="break-word";

// Ooops!!!! - Fixing PLM issue P140707-05423.
/* If text selection is tried before the Chromium WebView(33.0.0.0, android 4.4.4) gets the first focus, 
 * Text selection occurs but Action bar doesn't appear.
 * Abnormally, the issue occurs only when the designMode property of the document obj is set.
 * It doesn't occur when the contentEditable property of Element obj is set.
 * It is a kind of Chromium WebView Bug.
 */
//        window.document.designMode='On';
        window.document.body.contentEditable="true";

/*
 * For the issue that the view shakes when user types "enter" at the last line of the view
 * because Google never fix it.
 * Google asserted that it is a intented behaviour not a Webview issue.
 * But, obviously it is a bug of webview that occurs only at the last line when wrap_content is used.
 * A workaround Solution by Samsung.
 * The cursor height at the last line is needed as the padding bottom of WebView.
 * window.document.body.style.paddingBottom= 80;
*/
        window.document.body.style.paddingBottom= 80;

        mMaxBodyHtmlLen = window.HtmlEditingView.jsGetMaxHtmlLength();

        // set touchlistener at document
        window.document.addEventListener("touchstart", documentTouchDown, false);
        window.document.addEventListener("touchend", documentTouchUp, false);
        window.document.addEventListener("touchcancel", documentTouchCancel, false);
        window.document.addEventListener("touchmove", documentTouchMove, false);
        window.document.addEventListener("selectstart", onSelectionChanged, false);
        window.document.addEventListener("selectionchange", onSelectionChanged, false);
        window.document.addEventListener("compositionstart", onTextChangedEvent, false);
        window.document.addEventListener("compositionupdate", onTextChangedEvent, false);
        window.document.addEventListener("compositionend", onTextChangedEvent, false);
        window.document.addEventListener("beforeinput", onTextChangedEvent, false);
        window.document.addEventListener("input", onTextChangedEvent, false);
        window.document.addEventListener("paste", onPasteEvent, false);
        // beforeinput and input event is not yet implemented in chrome - http://www.w3.org/TR/2013/WD-DOM-Level-3-Events-20131105/
        window.document.addEventListener("textInput", onTextChangedEvent, false);
        window.addEventListener("resize", onResizeEvent, false);
        window.addEventListener("blur", onFocusChangedEvent, false);
        window.addEventListener("focus", onFocusChangedEvent, false);
        
        var mSignature = window.HtmlEditingView.jsGetSignature();
        console.log(mSignature);
        setSignature(mSignature);
        
        var imgs = document.images;
        for( i=0; i<imgs.length; i++ ) {
            imgs[i].removeEventListener("touchstart", imageTouchDown);
            imgs[i].removeEventListener("touchend", imageTouchUp);
            imgs[i].removeEventListener("touchcancel", imageTouchCancel);
            imgs[i].removeEventListener("touchmove", imageTouchMove);

            imgs[i].addEventListener("touchstart", imageTouchDown, false);
            imgs[i].addEventListener("touchend", imageTouchUp, false);
            imgs[i].addEventListener("touchcancel", imageTouchCancel, false);
            imgs[i].addEventListener("touchmove", imageTouchMove, false);

            if( 0 != imgs[i].src.lastIndexOf("content://com.samsung.android.email.attachmentprovider/")) {
                if( undefined == imgs[i].id || imgs[i].id == "" ) {
                    var d = new Date();
                    imgs[i].id = d.getTime();
                }
            } else {
                if( undefined != imgs[i].id ) imgs[i].id == "";
            }
        }

//        addHintElement();

        var range = document.createRange();
        range.setStart(window.document.body, 0);
        range.setEnd(window.document.body, 0);
        
        document.getSelection().removeAllRanges();
        document.getSelection().addRange(range);
    }

    function onFocusChangedEvent(event) {
        console.log("onFocusChangedEvent event.type = [" + event.type + "]");

        switch( event.type ) {
        case "blur": {
            if( window.curSelectedImage ) {
                deselectImage();
                var sel = window.getSelection();
                sel.removeAllRanges();
            }

            clearStackForTracingEvent();
        }
            break;
        case "focus": {
            if( !isImageSelected ) {
                var range = document.createRange(), sel = window.getSelection();
                range.setStart(window.document.body, 0);
                range.collapse(true);
    
                sel.removeAllRanges();
                sel.addRange(range);
            }
        }
            break;

        default:
            break;
        }
    }

    function onPasteEvent(event){
        window.HtmlEditingView.jsOnPaste();
        event.returnValue = false;
    }

    function onResizeEvent(event) {
        updateImageHandler();
    }

    function setSignature(value) {
        console.log("insert signature value : " + value);
        if (document.getElementById("composer_signature") || (!value)
            || (value == ""))
            return;
    
        var bodyElement = document.body, div = document.createElement('div');
        div.innerHTML = "<br>";
        bodyElement.appendChild(div.cloneNode(true));
        bodyElement.appendChild(div.cloneNode(true));
        bodyElement.appendChild(div.cloneNode(true));
        bodyElement.appendChild(div.cloneNode(true));
    
        div.id = "composer_signature";
        div.innerHTML = value;
        bodyElement.appendChild(div);
    }

    function insertContent(value, position) {
        console.log(position);

        var curBodyLength = getBodyHTML().bodyHTML.length;
        if( mMaxBodyHtmlLen < (curBodyLength + value.length) ) {
            window.HtmlEditingView.jsErrorResult(100);
            return false;
        }
 
        var body = document.getElementById('main');
        var range = document.createRange();
        if( 'INSERT_AT_BEGINNING' == position ) {
            range.setStart(body, 0);
            range.collapse(true);
            document.getSelection().removeAllRanges();
            document.getSelection().addRange(range);
        } else if( 'INSERT_AT_END' == position ) {
            range.setStartAfter(body);
            range.collapse(true);
            document.getSelection().removeAllRanges();
            document.getSelection().addRange(range);
        }
        console.log(value);
        command('insertHTML', value);
        window.HtmlEditingView.jsRichTextToolbarEnable(true);

        return true;
    }

    function insertContentForPasting(value, position) {
        console.log("insertContentForPasting Start");

        var result = insertContent(value, position);

        var imgs = document.images;
        for( i=0; i<imgs.length; i++ ) {
            imgs[i].removeEventListener("touchstart", imageTouchDown);
            imgs[i].removeEventListener("touchend", imageTouchUp);
            imgs[i].removeEventListener("touchcancel", imageTouchCancel);
            imgs[i].removeEventListener("touchmove", imageTouchMove);

            imgs[i].addEventListener("touchstart", imageTouchDown, false);
            imgs[i].addEventListener("touchend", imageTouchUp, false);
            imgs[i].addEventListener("touchcancel", imageTouchCancel, false);
            imgs[i].addEventListener("touchmove", imageTouchMove, false);

            var d = new Date();
            imgs[i].id = d.getTime();
        }

        console.log("insertContentForPasting End");

        return result;
    }

    function getMailContents(isRTL) {
        var webHTMLMarkupData = new Object();
        var clonedBody = document.body.cloneNode(true);
/*+ BIDI Concept Feature of Android +*/
        if(clonedBody.children) {
            if(!isRTL) {
                for( var i=0; i<clonedBody.children.length; i++ ) {
                    if( 'auto' == clonedBody.children[i].dir ) {
                        clonedBody.children[i].removeAttribute("dir");
                    }
                }
            } else {
                // Warning: Internet Explore doesn't support 'auto' of HTML5 as dir attribute, yet.
                // So, we SHOULD do this as the workaround.
                // It is same as KK.
                for( var i=0; i<clonedBody.children.length; i++ ) {
                    var text = clonedBody.children[i].innerText;
                    if( text.length > 0 && true == firstCharIsRTL(text.charCodeAt(0)) ) {
                        clonedBody.children[i].dir = 'rtl';
                    }
                }
            }
        }

        clonedBody.removeAttribute("dir");
/*- BIDI Concept Feature of Android -*/

        if( window.curSelectedImage ) {
            var selector = 'img#'+ window.curSelectedImage.id;
            var img = clonedBody.querySelector(selector);
            img.removeAttribute("style");

            for(var i = 7; i >= 0; i-- ) {
                var imgHandler = clonedBody.querySelector("div#imgHandler" + i);
                if( imgHandler ) {
                    imgHandler.parentNode.removeChild(imgHandler);
                }
            }
        }

        var isHintShowing = clonedBody.querySelector('span#sec_hint');
        if( isHintShowing ) {
            clonedBody.removeChild(isHintShowing);
        }

        webHTMLMarkupData.bodyHTML = clonedBody.innerHTML;
        webHTMLMarkupData.bodyText = clonedBody.innerText;

        var webSubPartList = new Array();
        var imgs;
        if( window.curSelectedImage ) {
            imgs = clonedBody.querySelectorAll("img");
        } else {
            imgs = document.images;
        }

        for( i=0; i<imgs.length; i++ ) {
            if( imgs[i].src.toLowerCase().substring(0, 7) != 'file://' 
                && imgs[i].src.toLowerCase().substring(0,10) != 'content://' ) {
                continue;
            }

            var webSubPart = new Object();
            webSubPart.cid= "cid:" + imgs[i].name;
            webSubPart.contentUri= imgs[i].src;

            webSubPartList[webSubPartList.length] = webSubPart;
        }

        webHTMLMarkupData.webSubPartList = webSubPartList;

        return webHTMLMarkupData;
    }

    function getBodyHTML() {
        var objBodyHTML = new Object();
        var clonedBody = document.body.cloneNode(true);
/*+ BIDI Concept Feature of Android +*/
        if(clonedBody.children) {
            for( var i=0; i<clonedBody.children.length; i++ ) {
                if( 'auto' == clonedBody.children[i].dir ) {
                    clonedBody.children[i].removeAttribute("dir");
                }
            }
        }

        clonedBody.removeAttribute("dir");
/*- BIDI Concept Feature of Android -*/

        if( window.curSelectedImage ) {
            var selector = 'img#'+ window.curSelectedImage.id;
            var img = clonedBody.querySelector(selector);
            img.removeAttribute("style");

            for(var i = 7; i >= 0; i-- ) {
                var imgHandler = clonedBody.querySelector("div#imgHandler" + i);
                if( imgHandler ) {
                    imgHandler.parentNode.removeChild(imgHandler);
                }
            }
        }

        var isHintShowing = clonedBody.querySelector('span#sec_hint');
        if( isHintShowing ) {
            clonedBody.removeChild(isHintShowing);
        }

        objBodyHTML.bodyHTML = clonedBody.innerHTML;

        return objBodyHTML;
    }

    function getBodyText() {
        var objBodyText = new Object();
        var clonedBody = document.body.cloneNode(true);

        var isHintShowing = clonedBody.querySelector('span#sec_hint');
        if( isHintShowing ) {
            clonedBody.removeChild(isHintShowing);
        }

        objBodyText.bodyText = clonedBody.innerText;
        console.log(objBodyText.bodyText);

        return objBodyText;
    }

    function getImagesInfo() {
        var webSubPartList = new Array();
        var imgs = document.images;
        for( i=0; i<imgs.length; i++ ) {
            if( imgs[i].src.toLowerCase().substring(0, 7) != 'file://' 
                && imgs[i].src.toLowerCase().substring(0,10) != 'content://' ) {
                continue;
            }

            var webSubPart = new Object();
            webSubPart.cid= "cid:" + imgs[i].name;
            webSubPart.contentUri= imgs[i].src;

            webSubPartList[i] = webSubPart;
        }

        return webSubPartList;
    }   

    function clear() {
        document.body.innerHTML = "";
    }

    function setCursorAtEndOfRangeSelection() {
        console.log("setCursorAtEndOfRangeSelection()");

        if( isImageSelected ) {
            deselectImage();
        }

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("setCursorAtEndOfRangeSelection() sel == null or 0 == sel.rangeCount");
            return;
        }

        var range = sel.getRangeAt(0);
        if( !range ) {
            console.log("setCursorAtEndOfRangeSelection() range == null");
            return;
        }

        if( !range.collapsed ) {
            console.log("setCursorAtEndOfRangeSelection() range.collapsed = " + range.collapsed);
            range.collapse(false);
            sel.removeAllRanges();
            sel.addRange(range);
        }
    }

    function setMaxHtmlLength(maxHtmlLength) {
    	mMaxBodyHtmlLen = maxHtmlLength;
    }

    function addHintElement() {
        var body = document.body;
        if( true == body.hasChildNodes() ) {
            if( 1 == body.children.length ) {
                var childNode = body.firstChild;
                if( childNode.nodeName && 'br' == childNode.nodeName.toLowerCase() ) {
                    body.removeChild(childNode);
                } else {
                    return;
                }
            } else {
                return;
            }
        }

        var strHint = window.HtmlEditingView.jsGetHint();
        var strHintTextColor = window.HtmlEditingView.jsGetHintTextColor();

        if( null == strHint ) return;

        var hintSpan = document.createElement("span");
        hintSpan.id = 'sec_hint';
        hintSpan.innerText = strHint;
        hintSpan.contentEditable = 'false';
        hintSpan.style.cssText = "-webkit-user-select: none;-webkit-user-modify: read-only;";

        if( -1 != strHintTextColor ) {
            var red = (strHintTextColor >> 16) & 0xFF;
            var green = (strHintTextColor >> 8) & 0xFF;
            var blue = strHintTextColor & 0xFF;
            var alpha = (strHintTextColor >>> 24) / 255;

            hintSpan.style.color = 'rgba(' + red + ', ' + green + ', ' + blue + ', ' + alpha + ')';
        }

        body.appendChild(hintSpan);
    }

    function removeHintElement() {
        var body = document.body;

        var length = body.childNodes.length;
        if( 2 <= length) {
            var isHintShowing = document.getElementById('sec_hint');
            if( isHintShowing ) {
                body.removeChild(isHintShowing);
            }
        }
    }

    function copy(isByHWKeyboard, /*optional*/isCut) {
        var objCopiedData = new Object();

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            return objCopiedData;
        }

        var range = sel.getRangeAt(0);
        if( !range ) {
            return objCopiedData;
        }

        if( !range.collapsed ) {
            console.log("copy() range.collapsed = " + range.collapsed + ", isCut = " + isCut);

            var htmlFragment = range.cloneContents();

            var div = document.createElement('div');
            div.appendChild(htmlFragment);

            objCopiedData.html = div.outerHTML;
            console.log(objCopiedData.html);

            div.setAttribute("type", "hidden");
            document.body.appendChild(div);
            objCopiedData.text = div.innerText;
            document.body.removeChild(div);

            if( isCut ) {
                document.execCommand('delete', false);
            } else {
                if( !isByHWKeyboard ) {
                    range.collapse(false);
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
            }
        }

        return objCopiedData;
    }

    function translate() {
        console.log("translate()");

        var selectedText = getSelectedHtmlText();
        if( selectedText == undefined ) {
            window.HtmlEditingView.jsTranslate("");
        } else {
            window.HtmlEditingView.jsTranslate(selectedText);
        }
    }

    function dictionary() {
        console.log("dictionary()");

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            return "";
        }

        var result = sel.toString();

        var objSelectedText = new Object();
        objSelectedText.text = result;

        return objSelectedText;
    }

/*+ BIDI Concept Feature of Android +*/
    function firstCharIsRTL(firstChar) {
        console.log("firstCharIsRTL firstChar = [" + firstChar + "]");
        if (firstChar == null) {
            return false;
        }

        if ((firstChar >= 0x0621 && firstChar <= 0x065F)
                    || (firstChar >= 0x066E && firstChar <= 0x06D3)
                    || (firstChar >= 0xFB50 && firstChar <= 0xFDFF)
                    || (firstChar >= 0xFE70 && testChar <= 0xFEFC)
                    || (firstChar == 0x061B || firstChar == 0x061F)) {
                return true;// Arabic Unicode Character Range
        }else if ((firstChar >= 0x0590 && firstChar <= 0x05FF) || firstChar == 0x200F) {
            return true;// Hebrew Unicode Character Range
        }else{
            return false;
        }

        return false;
    }

    /**
     * Checks for RTL char.
     * 
     * @param str the HTML string content
     * @return true, if String str contains RTL char
     */
    function hasRTLChar(str) {
        if (str == null) {
            return false;
        }
        var testChar;
        var length = str.length();
        for (var i = 0; i < length; i++) {
            testChar = str.codePointAt(i);
            // if condition check for arabic
            if ((testChar >= 0x0621 && testChar <= 0x065F)
                    || (testChar >= 0x066E && testChar <= 0x06D3)
                    || (testChar >= 0xFB50 && testChar <= 0xFDFF)
                    || (testChar >= 0xFE70 && testChar <= 0xFEFC)
                    || (testChar == 0x061B || testChar == 0x061F)) {
                return true;// Arabic Unicode Character Range
            } else if ((testChar >= 0x0590 && testChar <= 0x05FF)) {
                return true;// Hebrew Unicode Character Range
            }
        }
        return false;
    }
/*- BIDI Concept Feature of Android -*/

    function selectWord(x, y) {
        console.log("selectWord x = " + x + ", y = " + y);

        var range = document.createRange();
        var caretPosition = document.caretRangeFromPoint(x/window.devicePixelRatio, y/window.devicePixelRatio);
        
        range.setStart(caretPosition.startContainer, caretPosition.startOffset);
        range.setEnd(caretPosition.startContainer, caretPosition.startOffset);

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("selectWord() !sel OR 0 >= sel.rangeCount");
            return;
        }

        sel.removeAllRanges();
        sel.addRange(range);

        sel.modify("move", "backward", "word");
        sel.modify("extend", "forward", "word");
    }