    var stackForTracingEvent = [];
    var SelectionChangeType = {
        /*Unknown result*/
        "Unknown_Result" : -1,
        /* In case that user touches a position short*/
        "After_Short_Press" : 0,                                                // 'touchstart' > 'touchend' > 'selectstart' > 'selectionchange'
        /* In case that user touches a position long */
        "After_Long_Press" : 1,                                                 // 'touchstart' > 'selectstart' > 'selectionchange'
        /* In case that user moves cursor position using cursor handler */
        "After_Control_Cursor" : 2,                                             // 'selectionchange'
        /* In case that user changes a selected range using selection hander */
        "After_Control_DoubleCursor" : 3,                                       // 'selectionchange'
        /* In case of After_Control_Cursor OR After_Control_DoubleCursor */
        "After_Control_CursorOrDoubleCursor" : 4,                               // 'selectionchange'
        /* In case that prediction is OFF and user types */
        "After_Type_Char" : 5,                                                  // 'textInput' > 'input' > 'selectionchange'
        /* In case that prediction is ON and user starts composing text */
        "After_Start_Composing" : 6,                                            // 'compositionstart' > 'compositionupdate' > 'input' > 'selectionchange'
        /* In case that prediction is ON and user is composing text */
        "After_Update_Composing" : 7,                                           // 'compositionupdate' > 'input' > 'selectionchange'
        /* In case that prediction is ON and user completes composing text */
        "After_Complete_Composing" : 8,                                         // 'compositionend' > 'textInput' > 'input' > 'selectionchange'
        /* In case that user inserts a content */
        "After_Insert_Content" : 9                                              // 'input' > 'selectionchange'
    };

/*+ Accessibility Feature +*/
    var mBeforeText = undefined, mFromIndex = -1, mAddedCount = 0, mRemovedCount = 0;
    var mComposingStart = -1, mComposingEnd = -1;
/*- Accessibility Feature -*/

/*+ BIDI Concept Feature of Android +*/
    var mBodyChildrenCount = 0;
/*- BIDI Concept Feature of Android -*/

    var timerForSelChange = null;
    var timerForUpdatePosition = null;
    var _timeridForDisable = null;

    function onSelectionChanged(event) {
//	    console.log("onSelectChanged!!!!!!!!!!!!!!! event.type = [" + event.type + "]");

        switch(event.type) {
        case "selectstart":
            var result = stackForTracingEvent.push("selectstart");
            break;
        case "selectionchange": {
            var typeForUpdatingRichTextState = getRichTextUpdatePolicy();

            switch(typeForUpdatingRichTextState) {
            case SelectionChangeType.After_Type_Char: {
                // TODO call the method to update rich text state properly
                updateRichTextState(true);

//                removeHintElement();

                var text = document.body.innerText;
                window.HtmlEditingView.jsUpdateCurText(text);

/*+ Accessibility Feature +*/
                window.HtmlEditingView.jsSendAccessibilityEventTypeViewTextChanged(mFromIndex, mRemovedCount, mAddedCount, mBeforeText );
                mFromIndex = -1;
                mAddedCount = 0;
                mRemovedCount = 0;
                mBeforeText = undefined;
/*- Accessibility Feature -*/

                // TODO call the method to update rich text state properly
                if( null != timerForUpdatePosition ) {
                    clearTimeout(timerForUpdatePosition);
                    timerForUpdatePosition = null;
                }

                timerForUpdatePosition = setTimeout(function(){
                    var selectionInfo = getSelectionInfo();
                    var jsonResult = JSON.stringify(selectionInfo);
                    window.HtmlEditingView.jsCursorPositionChanged(jsonResult);
                }, 130);
            }
                return;

            case SelectionChangeType.After_Start_Composing: {
                // TODO call the method to update rich text state properly
                updateRichTextState(true);

//                removeHintElement();

                var text = document.body.innerText;
                window.HtmlEditingView.jsUpdateCurText(text);

/*+ Accessibility Feature +*/
                window.HtmlEditingView.jsSendAccessibilityEventTypeViewTextChanged(mFromIndex, mRemovedCount, mAddedCount, mBeforeText );
                mFromIndex = -1;
                mAddedCount = 0;
                mRemovedCount = 0;
                mBeforeText = undefined;
/*- Accessibility Feature -*/

                // TODO call the method to update rich text state properly
                if( null != timerForUpdatePosition ) {
                    clearTimeout(timerForUpdatePosition);
                    timerForUpdatePosition = null;
                }

                timerForUpdatePosition = setTimeout(function(){
                    var selectionInfo = getSelectionInfo();
                    var jsonResult = JSON.stringify(selectionInfo);
                    window.HtmlEditingView.jsCursorPositionChanged(jsonResult);
                }, 200);
            }
                return;

            case SelectionChangeType.After_Update_Composing: {
                // TODO call the method to update rich text state properly
                updateRichTextState(false);

                var text = document.body.innerText;
                window.HtmlEditingView.jsUpdateCurText(text);

/*+ Accessibility Feature +*/
                window.HtmlEditingView.jsSendAccessibilityEventTypeViewTextChanged(mFromIndex, mRemovedCount, mAddedCount, mBeforeText );
                mFromIndex = -1;
                mAddedCount = 0;
                mRemovedCount = 0;
                mBeforeText = undefined;
/*- Accessibility Feature -*/

                // TODO call the method to update rich text state properly
                if( null != timerForUpdatePosition ) {
                    clearTimeout(timerForUpdatePosition);
                    timerForUpdatePosition = null;
                }

                timerForUpdatePosition = setTimeout(function(){
                    var selectionInfo = getSelectionInfo();
                    var jsonResult = JSON.stringify(selectionInfo);
                    window.HtmlEditingView.jsCursorPositionChanged(jsonResult);
                }, 130);
            }
                return;

            case SelectionChangeType.After_Complete_Composing: {
                // TODO call the method to update rich text state properly
                updateRichTextState(true);

                var text = document.body.innerText;
                window.HtmlEditingView.jsUpdateCurText(text);
            }
                return;

            case SelectionChangeType.Unknown_Result:
            case SelectionChangeType.After_Short_Press:
                // TODO call the method to update rich text state properly
                updateRichTextState(true);
                break;
            case SelectionChangeType.After_Control_CursorOrDoubleCursor: {
                if( isImageSelected ) {
                    // Warning: Cursor occurs at start position when HtmlEditingView has no focus and a inserted image is touched.
                    // To remove the cursor, we SHOULD run this code part necessarily.
                    var sel = window.getSelection();
                    sel.removeAllRanges();
                    return;
                }

                if( null != timerForSelChange ) {
                    clearTimeout(timerForSelChange);
                    timerForSelChange = null;
                }

                timerForSelChange = setTimeout(function(){
                    updateRichTextState(true);

                    var selectionInfo = getSelectionInfo();
                    var jsonResult = JSON.stringify(selectionInfo);
                    window.HtmlEditingView.jsSelectionChanged(jsonResult);
                    if( true == selectionInfo.isCaret ) {
                        window.HtmlEditingView.jsCursorPositionChanged(jsonResult);
                    }
                }, 130);
            }
                return;

            case SelectionChangeType.After_Insert_Content: {
                // TODO call the method to update rich text state properly
                updateRichTextState(true);

                var text = document.body.innerText;
                window.HtmlEditingView.jsUpdateCurText(text);
                
                if( null != timerForUpdatePosition ) {
                    clearTimeout(timerForUpdatePosition);
                    timerForUpdatePosition = null;
                }

                timerForUpdatePosition = setTimeout(function(){
                    var selectionInfo = getSelectionInfo();
                    var jsonResult = JSON.stringify(selectionInfo);

                    window.HtmlEditingView.jsCursorPositionChanged(jsonResult);
                    window.HtmlEditingView.jsSelectionChanged(jsonResult);
                }, 200);
            }
                return;

            case SelectionChangeType.After_Long_Press:
                if( isImageSelected ) {
                    deselectImage();
                    prevSelectedImageObject = null;
                    selectedImageObject = null;
                    isImageMoveable = false;
                    window.HtmlEditingView.jsCanImageMove(false);
                }

                updateRichTextState(true);
                break;

            default:
                break;
            }

            var selectionInfo = getSelectionInfo();
            var jsonResult = JSON.stringify(selectionInfo);
            window.HtmlEditingView.jsSelectionChanged(jsonResult);
        }
            break;
        }
    }
    
    function onComposiongState(event) {
        switch (event.type) {
            case "compositionstart": {
                //toolbar disable
                    
                if(_timeridForDisable != null) {
                    clearTimeout(_timeridForDisable);
                    _timeridForDisable = null;
                }

                _timeridForDisable = setTimeout(function() {
                    console.log("setRichTextToolbarEnable false, delay = 40");
                    window.HtmlEditingView.jsRichTextToolbarEnable(false);
                    _timeridForDisable = null;
                }, 40);
 
                break;
            }
            case "compositionupdate": {
                if(_timerid != null) {
                    clearTimeout(_timerid);
                    _timerid = null;
                }
                break;
            }
            case "compositionend": {
                //toolbar enable
                if( null != _timeridForDisable ) {
                    clearTimeout(_timeridForDisable);
                    _timeridForDisable = null;
                } else {
                    (function setRichTextToolbarEnable(enable,/*optional*/delay) {
                        console.log(_timerid);
                        if(!delay) delay = 100; 
                    
                        if(_timerid != null) {
                            clearTimeout(_timerid);
                            _timerid = null;
                        }
                    
                        _timerid = setTimeout(function(enable) {
                                window.HtmlEditingView.jsRichTextToolbarEnable(enable);
                            }, delay, enable);
    
                        console.log("setRichTextToolbarEnable enable : " + enable, ",delay : " + delay);
                    })(true);
                }
                break;
            }
    
        }
    }

    function onTextChangedEvent(event) {
//        console.log("onTextChangedEvent type = [" + event.type + "], data = [" + event.data + "]");
        onComposiongState(event);
        switch(event.type) {
        case "compositionstart": {
//            removeHintElement();

            stackForTracingEvent.length = 0; 
            var result = stackForTracingEvent.push("compositionstart");

/*+ Accessibility Feature +*/
            var curSelOffset = getSelectionOffset();
            mComposingStart = curSelOffset.start;
            mComposingEnd = curSelOffset.end;
/*- Accessibility Feature -*/
        }
            break;
        case "compositionupdate": {
            var result = stackForTracingEvent.push("compositionupdate");

/*+ Accessibility Feature +*/
            if( mComposingStart != -1 && mComposingEnd != -1 && mComposingEnd >= mComposingStart ) {
                mRemovedCount = mComposingEnd - mComposingStart;
            }

            if( undefined == event.data ) {
                mAddedCount = 0;
            } else {
                mAddedCount = event.data.length;
            }

            mBeforeText = document.body.innerText;
            mFromIndex = mComposingStart;
            mComposingEnd = mComposingStart + mAddedCount;
/*- Accessibility Feature -*/
        }
            break;
        case "compositionend": {
            var result = stackForTracingEvent.push("compositionend");
        }
            break;
        case "input": {
//            removeHintElement();
//            addHintElement();

/*+ BIDI Concept Feature of Android +*/
            var body = document.body;
            if(body.children && mBodyChildrenCount != body.children.length) {
                console.log("@@@@@@@@@@@@@@@  body.children.length @@@@@@@@@@@@@@@@@@@ = [" + body.children.length + "]");

                for( var i=0; i<body.children.length; i++ ) {
                    if( "" == body.children[i].dir ) {
                        body.children[i].dir = 'auto';
                    }
                }

                mBodyChildrenCount = body.children.length;
            }
/*- BIDI Concept Feature of Android -*/

            var result = stackForTracingEvent.push("input");
        }
            break;
        case "textInput": {
//            removeHintElement();

            var result = stackForTracingEvent.push("textInput");

/*+ Accessibility Feature +*/
            var curSelOffset = getSelectionOffset();
            if( curSelOffset.start != -1 && curSelOffset.end != -1 && curSelOffset.start < curSelOffset.end ) {
                mRemovedCount = curSelOffset.end - curSelOffset.start;
            }

            if( mComposingStart != -1 && mComposingEnd != -1 && mComposingEnd >= mComposingStart ) {
                mRemovedCount = mComposingEnd - mComposingStart;
            }

            if( undefined == event.data ) {
                mAddedCount = 0;
            } else {
                mAddedCount = event.data.length;
            }

            mBeforeText = document.body.innerText;

            if( mComposingStart != -1 && mComposingEnd != -1 ) {
                mFromIndex = mComposingStart;
                mComposingStart = -1;
                mComposingEnd = -1;
            } else {
                mFromIndex = curSelOffset.start;
            }
/*- Accessibility Feature -*/
        }
            break;
        default:
            break;
        }
    }
    
    function requestCurrentTopPosition() {
        var newCaretRect = getCaretRect();
        var jsonResult = null;
        
        if(newCaretRect){
            jsonResult = JSON.stringify(newCaretRect);
            console.log("call : requestCurrentTopPosition : CaretPosition :"
                + " left = " + newCaretRect.left 
                + " top = " + newCaretRect.top
                + " right = " + newCaretRect.right 
                + " bottom = " + newCaretRect.bottom);
        } else {
            var selectionInfo = getSelectionInfo();
            if(selectionInfo.startBoundRect) {
                jsonResult = JSON.stringify(selectionInfo.startBoundRect);
                console.log("call : requestCurrentTopPosition : startBoundRect :"
                    + " left = " + selectionInfo.startBoundRect.left
                    + " top = " + selectionInfo.startBoundRect.top
                    + " right = " + selectionInfo.startBoundRect.right
                    + " bottom = " + selectionInfo.startBoundRect.bottom);
            }
        }
        
        window.HtmlEditingView.responseForRequestTopPosition(jsonResult);
    }

    function getCaretRect() {
        var caretRect = null;

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("getCaretRect() sel == null or 0 == sel.rangeCount");
            return caretRect;
        }

        var range = sel.getRangeAt(0);
        if( !range ) {
            console.log("getCaretRect() range == null");
            return caretRect;
        }

        var startContainer = range.startContainer;

        if( range.collapsed ) {
            var rectList = range.getClientRects();

            if( 1 == rectList.length ) {
                console.log("getCaretRect() left, top, right, bottom = ["
                        + rectList[0].left + ", " + rectList[0].top + ", " + rectList[0].right + ", " + rectList[0].bottom + "]");
                caretRect = new Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
            } else if( 0 == rectList.length && startContainer.tagName != "BODY" ) {
                var span = document.createElement("span");
                var textNodeForZWSP = document.createTextNode("\u200B");
                span.appendChild(textNodeForZWSP);
                range.insertNode(span);
                console.log("getCaretRect() processing range.toString() = [" + range.toString() + "]");
                rectList = span.getClientRects();

                if( 1 == rectList.length ) {
                    range.selectNode(span);
                    range.deleteContents();

                    console.log("getCaretRect() processing, left, top, right, bottom = ["
                            + rectList[0].left + ", " + rectList[0].top + ", " + rectList[0].right + ", " + rectList[0].bottom + "]");
                    caretRect = new Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
                }
            }
        }

        return caretRect;
    }

    function getSelectionInfo() {
        var startBoundRect = null;
        var endBoundRect = null;
        var selectionInfo = null;

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("getSelectionInfo() sel == null or 0 == sel.rangeCount");
            return selectionInfo;
        }

        var range = sel.getRangeAt(0);
        if( !range ) {
            console.log("getSelectionInfo() range == null");
            return selectionInfo;
        }

        var startContainer = range.startContainer;
        var startOffset = range.startOffset;

        if( !range.collapsed ) {
            console.log("getSelectionInfo() range.collapsed = [" + range.collapsed +"]");

            var rectList = range.getClientRects();
            console.log("getSelectionInfo()  rectList.length = [" + rectList.length + "]");

            if( rectList.length > 0 ) {
                var length = rectList.length;
                startBoundRect = new Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
                endBoundRect = new Rect(rectList[length-1].left, rectList[length-1].top, rectList[length-1].right, rectList[length-1].bottom);
                selectionInfo = new SelectionInfo(startBoundRect, endBoundRect, sel.toString());
            }

            if( null == selectionInfo ) {
                startBoundRect = new Rect(-1, -1, -1, -1);
                selectionInfo = new SelectionInfo(startBoundRect, startBoundRect, sel.toString());
            }
        } else {
            console.log("getSelectionInfo() range.collapsed = [" + range.collapsed +"]");

            var rectList = range.getClientRects();
            if (0 == rectList.length && startContainer.tagName != "BODY" ) {
                var span = document.createElement("span");
                var textNodeForZWSP = document.createTextNode("\u200B");
                span.appendChild(textNodeForZWSP);
                range.insertNode(span);
                console.log("getSelectionInfo()  getClientRect processing range.toString() = [" + range.toString() + "]");
                rectList = span.getClientRects();
                
                if( 1 == rectList.length ) {
                    range.selectNode(span);
                    range.deleteContents();

                    console.log("getSelectionInfo()  getClientRect processing, left, top, right, bottom = ["
                            + rectList[0].left + ", " + rectList[0].top + ", " + rectList[0].right + ", " + rectList[0].bottom + "]");
                    startBoundRect = new Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
                    selectionInfo = new SelectionInfo(startBoundRect, startBoundRect);
                } 
            } else if( 1 <= rectList.length ) {
                if (startContainer.tagName == "BODY" && document.body.children.length == 0 ){
                	var span = document.createElement("span");
                    var textNodeForZWSP = document.createTextNode("\u200B");
                    span.appendChild(textNodeForZWSP);
                    range.insertNode(span);
                    console.log("getSelectionInfo()  getClientRect processing range.toString() = [" + range.toString() + "]");
                    rectList = span.getClientRects();
                    range.selectNode(span);
                    range.deleteContents();
                    
                }
                console.log("getSelectionInfo()  getClientRect, left, top, right, bottom = ["
	                    + rectList[0].left + ", " + rectList[0].top + ", " + rectList[0].right + ", " + rectList[0].bottom + "]");
	            startBoundRect = new Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
                selectionInfo = new SelectionInfo(startBoundRect, startBoundRect);
            } 

            if( null == selectionInfo ) {
                startBoundRect = new Rect(-1, -1, -1, -1);
                selectionInfo = new SelectionInfo(startBoundRect, startBoundRect);
            }
        }
        
        return selectionInfo;
    }

    function getSelectionOffset() {
        var selOffset = new SelectionOffset(-1,-1);

        return selOffset;
    }

    function getRichTextUpdatePolicy() {
        var result = SelectionChangeType.Unknown_Result;
        var event = stackForTracingEvent.pop();
//        console.log("getRichTextUpdatePolicy() event = [" + event + "]");

        switch(event) {
        case "input":
            result = analyzeInputEvent();
            break;
        case "textInput":
            event = stackForTracingEvent.pop();
            if( "compositionend" == event ) {
                result = SelectionChangeType.After_Complete_Composing;
            }
            break;
        case "selectstart":
            result = analyzeSelectStartEvent();
            break;
        case "touchend":
            stackForTracingEvent.length = 0;    // As "touchstart" will remain but won't be used.
            result = SelectionChangeType.After_Short_Press;
            break;
        default:    // undefined
            // To use "SelectionChangeType.After_Control_CursorOrDoubleCursor",
            // we NEED to consider more conditions
            result = SelectionChangeType.After_Control_CursorOrDoubleCursor;
            break;
        }

//        console.log("getRichTextUpdatePolicy() result = [" + result + "]");

        return result;
    }

    function analyzeInputEvent() {
        var result = SelectionChangeType.Unknown_Result;
        var event = stackForTracingEvent.pop();

        switch(event) {
        case "compositionupdate": {
            event = stackForTracingEvent.pop();
            if( "compositionstart" == event ) {
                result = SelectionChangeType.After_Start_Composing;
            } else if( undefined == event ) {
                result = SelectionChangeType.After_Update_Composing;
            }
        }
            break;
        case "textInput":
            stackForTracingEvent.length = 0; 
            result = SelectionChangeType.After_Type_Char;
            break;
        default:    // undefined
            result = SelectionChangeType.After_Insert_Content;
            break;
        }

        return result;
    }

    function analyzeSelectStartEvent() {
        var result = SelectionChangeType.Unknown_Result;
        var event = stackForTracingEvent.pop();

        switch(event) {
        case "touchend":
            stackForTracingEvent.length = 0;    // As "touchstart" will remain but won't be used.
            result = SelectionChangeType.After_Short_Press;
            break;
        case "touchstart":
            result = SelectionChangeType.After_Long_Press;
            break;
        case "input":
            result = analyzeInputEvent();
            break;
        default:    // undefined
            result = SelectionChangeType.Unknown_Result;
            break;
        }

        return result;
    }
    
    function clearStackForTracingEvent() {
        stackForTracingEvent.length = 0; 
    }

    function getSelectedHtmlText() {
        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            return undefined;
        }

        var range = sel.getRangeAt(0);
        if( !range ) {
            return undefined;
        }

        if( !range.collapsed ) {
            var htmlFragment = range.cloneContents();
            var div = document.createElement('div');
            div.appendChild(htmlFragment);

            var selectedHtmlText = div.outerHTML;
            console.log(selectedHtmlText);
            if( div.innerText.length > 0 ) {
                return selectedHtmlText;
            } else {
                return undefined;
            } 
        } else {
            return undefined;
        }
    }

    function getSelectionInfoWithJSON() {
        var info = getSelectionInfo();
        if(!info) return null;

        var selectionInfo = new Object();
        var startBoundRect = new Object();
        var endBoundRect = new Object();
        var selectionRect = new Object();

        if(info.startBoundRect) {
            startBoundRect.left = info.startBoundRect.left;
            startBoundRect.top = info.startBoundRect.top;
            startBoundRect.right = info.startBoundRect.right;
            startBoundRect.bottom = info.startBoundRect.bottom;
            startBoundRect.width = info.startBoundRect.witdh;
            startBoundRect.height = info.startBoundRect.height;
        }
        
        if(info.endBoundRect) {
            endBoundRect.left = info.endBoundRect.left;
            endBoundRect.top = info.endBoundRect.top;
            endBoundRect.right = info.endBoundRect.right;
            endBoundRect.bottom = info.endBoundRect.bottom;
            endBoundRect.width = info.endBoundRect.witdh;
            endBoundRect.height = info.endBoundRect.height;
        }
        if(info.selectionRect) {
            selectionRect.left = info.selectionRect.left;
            selectionRect.top = info.selectionRect.top;
            selectionRect.right = info.selectionRect.right;
            selectionRect.bottom = info.selectionRect.bottom;
            selectionRect.width = info.selectionRect.witdh;
            selectionRect.height = info.selectionRect.height;
        }

        selectionInfo.startBoundRect = startBoundRect;
        selectionInfo.endBoundRect = endBoundRect;
        selectionInfo.selectionRect = selectionRect;
        if( info.selectedText == undefined ) {
            selectionInfo.selectedText = "";
        } else {
            selectionInfo.selectedText = info.selectedText;
        }
        selectionInfo.isCaret = info.isCaret;
        selectionInfo.isRange = info.isRange;

        return selectionInfo;
    }

    function SelectionOffset( start, end ) {
        this.start = start;
        this.end = end;

        this.setOffset = setOffset;
        function setOffset(start, end) {
            this.start = start;
            this.end = end;
        }
    }

    function Rect( left, top, right, bottom ) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        this.width = right - left;
        this.height = bottom - top;
    }

    function SelectionInfo( startBoundRect, endBoundRect, /*optional*/selectedText ) {
        this.startBoundRect = startBoundRect;
        this.endBoundRect = endBoundRect;
        this.selectedText = selectedText;
        this.isCaret = false;
        this.isRange = false;

        if( startBoundRect == endBoundRect ) {
            if( -1 == startBoundRect.left
                && -1 == startBoundRect.top
                && -1 == startBoundRect.right
                && -1 == startBoundRect.bottom ) {
                if( selectedText ) {
                    this.isRange = true;
                }
            } else {
                this.isCaret = true;
            }
            this.isRange = false;
            this.selectionRect = new Rect(startBoundRect.left,
                                        startBoundRect.top,
                                        startBoundRect.right,
                                        startBoundRect.bottom);
        } else {
            this.isCaret = false;
            this.isRange = true;
            this.selectionRect = new Rect(startBoundRect.left,
                                        startBoundRect.top,
                                        endBoundRect.right,
                                        endBoundRect.bottom);
        }
    }

//+Feature_SPen_Gesture_TextSelection
    function selectBWStartAndEnd(startX, startY, endX, endY) {
        console.log("selectBWStartAndEnd startX = " + startX + ", startY = " + startY + ", endX = " + endX + ", endY = " + endY);

        var range = document.createRange();
        var startPosition = document.caretRangeFromPoint(startX/window.devicePixelRatio, startY/window.devicePixelRatio);
        var endPosition = document.caretRangeFromPoint(endX/window.devicePixelRatio, endY/window.devicePixelRatio);
        
        range.setStart(startPosition.startContainer, startPosition.startOffset);
        range.setEnd(endPosition.startContainer, endPosition.startOffset);

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("selectBWStartAndEnd() !sel OR 0 >= sel.rangeCount");
            return;
        }

        sel.removeAllRanges();
        sel.addRange(range);
    }
//-Feature_SPen_Gesture_TextSelection
    
    function moveCursorToLastOfBody() {
        var range = document.createRange(), sel = window.getSelection();
        var showIME = false;
        
        if( isImageSelected ) {
            deselectImage();
            prevSelectedImageObject = null;
            selectedImageObject = null;
            isImageMoveable = false;
            window.HtmlEditingView.jsCanImageMove(false);
            showIME = true;
        }
        
        if (document.body.hasChildNodes() == true) {
            var node = document.body.lastChild;
            if( Node.TEXT_NODE == node.nodeType ) {
                range.setStart(node, node.length);
                range.setEnd(node, node.length);
            } else {
                if( node.id && node.id.toLowerCase() == 'sec_hint' ) {
                    range.setStartBefore(node);
                    range.setEndBefore(node);
                } else {
                    range.setStartAfter(node);
                    range.setEndAfter(node);
                }
            }
        } else {
            range.selectNode(document.body);
        }
    
        sel.removeAllRanges();
        sel.addRange(range);

        return showIME;
    }

    function moveCursorToFirstOfBody() {
        var range = document.createRange(), sel = window.getSelection();
        var showIME = false;

        if( isImageSelected ) {
            deselectImage();
            prevSelectedImageObject = null;
            selectedImageObject = null;
            isImageMoveable = false;
            window.HtmlEditingView.jsCanImageMove(false);
            showIME = true;
        }

        if (document.body.hasChildNodes() == true) {
            var node = document.body.firstChild;


            range.setStartBefore(node);
            range.setEndBefore(node);
        } else {
            range.selectNode(document.body);
        }

        sel.removeAllRanges();
        sel.addRange(range);

        return showIME;
    }

    function deleteByShortcut() {
        console.log("deleteByShortcut()");
        var selectionInfo = getSelectionInfo();
        
        if(!selectionInfo.isCaret){
            document.execCommand("delete");
        }
    }