    function command(name, value) {
        if( 'insertText' == name ) {
            var curBodyLength = getBodyHTML().bodyHTML.length;
            if( mMaxBodyHtmlLen < (curBodyLength + value.length) ) {
                window.HtmlEditingView.jsErrorResult(-1);
                return;
            }
        }

        document.execCommand(name, false, value);
    }

    function getFontFace() {
        var fontFace = document.queryCommandValue('fontName');
//        console.log("getFontFace @@@@@@ fontFace queryCommandValue = [" + fontFace + "]");

        return fontFace;
    }

/*+ Font size change feature +*/
    function getFontSize() {
        var fontSize = document.queryCommandValue('fontSize');
//        console.log("getFontSize ########## fontSize queryCommandValue = [" + fontSize + "]");

        fontSize = getSupportedFontSize(fontSize);
//        console.log("getFontSize ########## actual fontSize = [" + fontSize + "]");
        
//        console.log("getFontSize() return value : " + fontSize);
        return fontSize;
    }

    function getSupportedFontSize(fontSize){
    	var result = 12;

//        console.log("getSupportedFontSize ########## fontSize = [" + fontSize + "]");

        switch(parseInt(fontSize)) {
        case 1:
            result = 8;
            break;
        case 2:
            result = 10;
            break;
        case 3:
            result = 12;
            break;
        case 4:
            result = 14;
            break;
        case 5:
            result = 18;
            break;
        case 6:
            result = 24;
            break;
        case 7:
            result = 36;
            break;
        default:
            break;
        }

//        console.log("getSupportedFontSize result = [" + result + "]");

        return result;
    }
    
    function setFontSize(value) {
        console.log("setFontSize() value : " + value);
        document.execCommand("FontSize", false, value);
    }
/*-Font size change feature-*/

    function updateRichTextState(updateFontSize) {

        var result = 0x0;
        var fontSize = -1;
        var fontFace = null;
        
        if(updateFontSize) {
            fontFace = getFontFace();
            fontSize = getFontSize();
        }
            
        var canUndo = document.queryCommandEnabled("undo");
        if(canUndo==true) {
            result |= 0x1000;
        }

        var canRedo = document.queryCommandEnabled("redo");
        if(canRedo==true) {
            result |= 0x2000;
        }

        var state = document.queryCommandState("bold");
        var indeterm = document.queryCommandIndeterm("bold");
        if(state==true) {
            result |= 0x1;
        } else if(state==false) {
            if(indeterm==true) result |=0x2;
            else result |= 0x0;
        } else if(state==null) {
            result |= 0x0;
        }

        state = document.queryCommandState("italic");
        indeterm = document.queryCommandIndeterm("italic");
        if(state==true) {
            result |= 0x4;
        } else if(state==false) {
            if(indeterm==true) result |=0x8;
            else result |=0x0;
        } else if(state==null) {
            result |=0x0;
        }

        state = document.queryCommandState("underline");
        indeterm = document.queryCommandIndeterm("underline");
        if(state==true) {
            result |= 0x10;
        } else if(state==false) {
            if(indeterm==true) result |=0x20;
            else result |=0x0;
        } else if(state==null) {
            result |=0x0;
        }

        state = document.queryCommandState("insertOrderedList");
        indeterm = document.queryCommandIndeterm("insertOrderedList");
        if(state==true) {
            result |= 0x40;
        } else if(state==false) {
            if(indeterm==true) result |=0x80;
            else result |=0x0;
        } else if(state==null) {
            result |=0x0;
        }

        state = document.queryCommandState("insertUnorderedList");
        indeterm = document.queryCommandIndeterm("insertUnorderedList");
        if(state==true) {
            result |= 0x100;
        } else if(state==false) {
            if(indeterm==true) result |=0x200;
            else result |=0x0;
        } else if(state==null) {
            result |=0x0;
        }
        
        state = document.queryCommandState("StrikeThrough");
        indeterm = document.queryCommandIndeterm("StrikeThrough");
        if(state==true) {
            result |= 0x400;
        } else if(state==false) {
            if(indeterm==true) result |=0x800;
            else result |=0x0;
        } else if(state==null) {
            result |=0x0;
        }
        

//        console.log(result);
        window.HtmlEditingView.jsRichTextStateUpdateFinished(result, fontFace, fontSize);
    }

    /*+Table feature+*/
    var temp;
    function setTableClickCheker(row, colume) {
        temp = new Array(row);
        for(var i = 0; i < row ; ++i) {
            temp[i] = new Array(colume);
            for(var j = 0 ; j < colume ; ++j)
                temp[i][j] = false;
        }
    }

    function OnTdClick(tableid, row, colume) {
        var check = false;

        if (temp[row-1][colume-1] == false)
            check = true;

        var tableSearch =  document.getElementById('yktable1');

        for(var i = 0; i < temp.length ; ++i) {
            for(var j = 0 ; j < temp[i].length ; ++j)
                if (temp[i][j] == true) {
                    tableSearch.rows[i].cells[j].style.backgroundColor = "white";
                    temp[i][j] = false;
                }
        }

        if(check == true)
            tableSearch.rows[row-1].cells[colume-1].style.backgroundColor = "aquamarine";
        else if (check == false)
            tableSearch.rows[row-1].cells[colume-1].style.backgroundColor = "white";

        temp[row-1][colume-1] = check;
    }
    /*-Table feature-*/