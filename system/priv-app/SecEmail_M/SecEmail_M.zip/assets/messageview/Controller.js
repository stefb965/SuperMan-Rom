var Controller = root.Controller = {};

/**
 * Debug flag
 */
var isDebug = true,
	debugLevel = 0, // 0(default), 1(detail), 2(font-size)
	/**
	 * @param {boolean} debug flag
	 */
	setDebug = function(debug) {
		isDebug = debug;
	},
	/**
	 * @param {int} debug level
	 */
	setDebugLevel = Controller.setDebugLevel = function(level) {
		debugLevel = level;
	},
	/**
	 * @param {string} log
	 * @param {int} 0(default), 1(detail), 2(font-size)
	 */
	Log = Controller.Log = function(log, level) {
		if (level == undefined) {
			level = 0;
		}
	
		if (isDebug && debugLevel >= level) {
			level != undefined
			console.log("[" + level + "]" + log);
		}
	};

/**
 * AutoFit flag
 * 
 * @param {boolean} autofit state
 */
var isAutoFit = false,
	setAutoFit = function(autoFit) {
		isAutoFit = autoFit;
	};

/**
 * MessageWebview Call function
 */
var Callback = {
	OnLoad : function(width, fontScale, minSize) {
		window.MessageWebViewJSInterface.jsLoad(width, fontScale, minSize);
	},
	OnResize : function(curViewPort, width, height, docWidth, docHeight) {
		window.MessageWebViewJSInterface.jsResize(curViewPort, width, height,
				docWidth, docHeight);
	},
	GetWidthByBaseViewport : function() {
		return window.MessageWebViewJSInterface.jsGetWidthByBaseViewport();
	},
	IsPLMCSSStyle : function() {
    		return window.MessageWebViewJSInterface.jsIsPLMCSSStyle();
    	},
	SelectionChanged : function(selectionText) {
		return window.MessageWebViewJSInterface.jsSelectionChanged(selectionText);
	}
};

Controller.onSelectionChanged = function(event) {
	Selection.onSelectionChanged(event, Callback.SelectionChanged);
};

Controller.onLoad = function(isAutoFit, baseFontSize, useSelectionChange) {
	this.isAutoFit = isAutoFit;
	document.title = "";

	addEvent();

	//	window.onresize = function() {
	//		var div = document.getElementById('MessageWebViewDiv');
	//		Callback.OnResize(980, parseInt(div.offsetWidth), parseInt(Math.max(
	//				div.offsetHeight, div.scrollHeight)), parseInt(document.width),
	//				parseInt(document.height));
	//	}

	if (this.isAutoFit) {
		AutoFit.onLoad(Callback.OnLoad, Callback.GetWidthByBaseViewport,
				Callback.IsPLMCSSStyle, baseFontSize);
	}

	measurePositions();
	Log("onLoad(" + DOC_BASE_URI + ")", 0);
};

Controller.onReLoad = function() {
	var retVal = AutoFit.onReLoad(Callback.OnLoad,
			Callback.GetWidthByBaseViewport, Callback.IsPLMCSSStyle);

	if (retVal == true) {
		measurePositions();
		Log("onReLoad(" + DOC_BASE_URI + ") - change the zoom scale", 0);
	}
	Log("onReLoad(" + DOC_BASE_URI + ") - don't change.", 0);
};

/**
 * for Word wrap
 */
var mouseMove = false, prevOffsetHeight = -1; centerPoint = false, selectElement = null;
var getTwoTouchPointData = function(evt) {
	var points = false, touches = evt.touches;
	if (touches.length === 2) {
		points = {
			x1 : touches[0].clientX,
			y1 : touches[0].clientY,
			x2 : touches[1].clientX,
			y2 : touches[1].clientY,
			x3 : touches[0].pageX,
			y3 : touches[0].pageY,
			x4 : touches[1].pageX,
			y4 : touches[1].pageY
		}
		points.centerX = (points.x1 + points.x2) / 2;
		points.centerY = (points.y1 + points.y2) / 2;
		points.pageX = (points.x3 + points.x4) / 2;
		points.pageY = (points.y3 + points.y4) / 2;
		return points;
	}
	return points;
};

Controller.onScaleChanged = function(evt) {
	var div = document.getElementById('MessageWebViewDiv');
	var scrollTop = document.body.scrollTop;

	div.style.width = div.scrollWidth = (window.innerWidth - div.offsetLeft) + "px";

	if (selectElement && prevOffsetHeight != document.body.offsetHeight) {
		var rectInfo = selectElement.getBoundingClientRect();
		var parent = selectElement.offsetParent;
		if (parent != selectElement) {
			while (parent) {
				rectInfo.left += parent.offsetLeft;
				rectInfo.top += parent.offsetTop;
				parent = parent.offsetParent;
			}
		}

		selectElement.scrollIntoView();
		if (selectElement.nodeName == "IMG") {
			window.scrollTo(window.scrollX, window.scrollY - (window.innerHeight / 5));
		} else {
			window.scrollTo(window.scrollX + rectInfo.left - div.offsetLeft, window.scrollY - (window.innerHeight / 2));
		}

		Log("onScaleChanged(" + DOC_BASE_URI + ") - nodeName["
				+ selectElement.nodeName + "]\r\nselectElement["
				+ selectElement.innerText + "]", 1);
	}

	Log("onScaleChanged()", 1);
};

/**
 * Touch event
 */
Controller.onTouchDown = function(evt) {
	if (evt.touches.length == 1 && mouseMove == false) {
		prevOffsetHeight = document.body.offsetHeight;
	}
}

Controller.onTouchUp = function(evt) {
	if (centerPoint) {
		if (selectElement == null) {
			var createNode = document.caretRangeFromPoint(centerPoint.centerX, centerPoint.centerY);
			var range = document.createRange();
			range.setStart(createNode.startContainer, createNode.startOffset);
			range.setEnd(createNode.startContainer, createNode.startOffset);
			selectElement = document.createElement("p");
			range.insertNode(selectElement);
		}
	    Controller.onScaleChanged(evt);
	}

	mouseMove = false;
	prevOffsetHeight = -1;
	centerPoint = false;
	if (selectElement) {
		if (selectElement.nodeName != "IMG") {
			selectElement.parentNode.removeChild(selectElement);
		}

		selectElement = null;
	}
}

Controller.onTouchMove = function(evt) {
	if (evt.touches.length > 1) {
		centerPoint = getTwoTouchPointData(evt);
		var element = document.elementFromPoint(centerPoint.centerX,
				centerPoint.centerY);
		if (element) {
			if (element.nodeName == "IMG") {
				selectElement = element;
			}
		}
	}
}

/**
 * Add event listener
 */
var addEvent = Controller.addEvent = function() {
	//window.document.addEventListener('selectstart', Controller.onSelectionChanged,
	//		false);
	if (USE_SELECTION_CHANGE) {
		window.document.addEventListener('selectionchange',
				Controller.onSelectionChanged, false);
	}

	if (USE_WORD_WRAPPING) {
		window.document.addEventListener("touchstart", Controller.onTouchDown,
				false);
		window.document.addEventListener("touchend", Controller.onTouchUp,
				false);
		window.document.addEventListener("touchmove", Controller.onTouchMove,
				false);
	}
	Log("addEvent()", 1);
};

/**
 * Execute
 */
Controller.onCommand = function(name, value) {
	document.execCommand(name, false, value);
	Log("onCommand() - name[" + name + "] value[" + value + "]");
};