// Do this first to ensure that the readiness signal comes through,
// even if a stray exception later occurs.
if (!CHANGE_FONT_SIZE_BY_JAVASCRIPT) {
	setupContentReady();
	
	collapseAllQuotedText();
	hideAllUnsafeImages();
	normalizeAllMessageWidths();
	//setWideViewport();
	// hack for b/1333356
	if (!RUNNING_KITKAT_OR_LATER) {
	    restoreScrollPosition();
	}
} else {
	if(IS_AUTOFIT) {
		setupContentReady();
		
		if(!IS_RELOAD) {
			normalizeAllMessageWidths();
		}
	} else {
		setupContentReady();
		
		collapseAllQuotedText();
		hideAllUnsafeImages();
		normalizeAllMessageWidths();
		//setWideViewport();
		// hack for b/1333356
		if (!RUNNING_KITKAT_OR_LATER) {
		    restoreScrollPosition();
		}
		
		measurePositions();
	}		
}

