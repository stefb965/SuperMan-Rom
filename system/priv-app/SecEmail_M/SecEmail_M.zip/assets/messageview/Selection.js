var MAX_LENGTH = 100;

var Selection = {
	onSelectionChanged : function(event, callback) {
		Controller
				.Log("onSelectChanged - event.type = [" + event.type + "]", 1);

		switch (event.type) {
			case "selectionchange": {
				var selectionInfo = this.getSelectionInfo(), jsonResult = null;
	
				if (selectionInfo) {
					if (selectionInfo.isRange) {
						jsonResult = JSON.stringify(selectionInfo);
						callback(jsonResult);
					} else {
						this.onPatternMatching(callback);
					}
				}
				
				Controller.Log("onSelectChanged - callback = [" + callback
						+ "] json[" + jsonResult + "]", 1);
			}
				break;
		}
	},
	
	getSelectionInfo : function(isSetRange) {
		var startBoundRect = null,
			endBoundRect = null,
			selectionInfo = null,
			sel = window.getSelection(),
			range = null;

		if (!sel || 0 >= sel.rangeCount) {
			Controller.Log(
					"getSelectionInfo() sel == null or 0 == sel.rangeCount", 1);
			return selectionInfo;
		}

		range = sel.getRangeAt(0);
		if (!range) {
			Controller.Log("getSelectionInfo() range == null", 1);
			return selectionInfo;
		}

		if (!range.collapsed) {
			Controller.Log("getSelectionInfo() range.collapsed = [" + range.collapsed + "]", 1);

			var rectList = range.getClientRects(),
				length = rectList.length;
			Controller.Log("getSelectionInfo()  rectList.length = [" + rectList.length + "]", 1);

			if (rectList.length > 0) {
				for (var i = 0; i < rectList.length; i++) {
					Controller.Log("getSelectionInfo()  rectList = [" + i + "], left, top, right, bottom = ["
							+ rectList[i].left + ", " + rectList[i].top + ", " + rectList[i].right + ", " + rectList[i].bottom
							+ "]", 1);
				}

				startBoundRect = new this.Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
				endBoundRect = new this.Rect(rectList[length - 1].left, rectList[length - 1].top, rectList[length - 1].right, rectList[length - 1].bottom);
				selectionInfo = new this.SelectionInfo(startBoundRect, endBoundRect, sel.toString());
			}
		} else {
			Controller.Log("getSelectionInfo() range.collapsed = [" + range.collapsed + "]", 1);

			var rectList = range.getClientRects();
			if (1 == rectList.length) {
				Controller.Log( "getSelectionInfo()  getClientRect, left, top, right, bottom = [" + rectList[0].left + ", " + rectList[0].top
								+ ", " + rectList[0].right + ", " + rectList[0].bottom + "]", 1);
				startBoundRect = new this.Rect(rectList[0].left, rectList[0].top, rectList[0].right, rectList[0].bottom);
				selectionInfo = new this.SelectionInfo(startBoundRect, startBoundRect);
			} else if (0 == rectList.length) {
				var span = document.createElement("span"),
					textNodeForZWSP = document.createTextNode("\u200B");

				span.appendChild(textNodeForZWSP);
				range.insertNode(span);
				Controller.Log(
						"getSelectionInfo()  getClientRect processing range.toString() = ["
								+ range.toString() + "]", 1);
				rectList = span.getClientRects();

				if (1 == rectList.length) {
					range.selectNode(span);
					range.deleteContents();

					Controller.Log(
							"getSelectionInfo()  getClientRect processing, left, top, right, bottom = ["
									+ rectList[0].left + ", " + rectList[0].top
									+ ", " + rectList[0].right + ", "
									+ rectList[0].bottom + "]", 1);
					startBoundRect = new this.Rect(rectList[0].left,
							rectList[0].top, rectList[0].right,
							rectList[0].bottom);
					selectionInfo = new this.SelectionInfo(startBoundRect,
							startBoundRect);
				}
			}
		}

		var curSelOffset = this.getSelectionOffset(isSetRange);
		selectionInfo.setSelectionOffset(curSelOffset.start, curSelOffset.end,
				curSelOffset.afterText);

		return selectionInfo;
	},

	getSelectionOffset : function(isSetRange) {
		var selOffset = new this.SelectionOffset(-1, -1),
			sel = window.getSelection(),
			range = null;

		if (!sel || 0 >= sel.rangeCount) {
			return selOffset;
		}

		range = sel.getRangeAt(0);

		if (!range) {
			return selOffset;
		}

		var startContainer = range.startContainer,
			endContainer = range.endContainer,
			startOffset = range.startOffset,
			endOffset = range.endOffet,
			leftPartRange,
			leftPartFragment,
			tmpForLeftPart,
			leftPartText,
			selPartFragment,
			tmpForSelPart,
			selPartText;

		if (range.collapsed) {
			if ((Node.TEXT_NODE != startContainer.nodeType)
					|| (Node.TEXT_NODE == startContainer.nodeType && startOffset == 0)) {
				selOffset.setAfterText(false);
			}
		}

		leftPartRange = document.createRange();
		leftPartRange.setStartBefore(document.body.firstChild);
		leftPartRange.setEnd(startContainer, startOffset);

		leftPartFragment = leftPartRange.cloneContents();
		tmpForLeftPart = document.createElement('div');
		tmpForLeftPart.setAttribute("type", "hidden");
		tmpForLeftPart.appendChild(leftPartFragment);
		document.body.appendChild(tmpForLeftPart);
		leftPartText = tmpForLeftPart.innerText;
		document.body.removeChild(tmpForLeftPart);

		selPartFragment = range.cloneContents();
		tmpForSelPart = document.createElement('div');
		tmpForSelPart.setAttribute("type", "hidden");
		tmpForSelPart.appendChild(selPartFragment);
		document.body.appendChild(tmpForSelPart);
		selPartText = tmpForSelPart.innerText;
		document.body.removeChild(tmpForSelPart);

		if (isSetRange == true) {
			selOffset
					.setOffset(Math.max(0, leftPartText.length - MAX_LENGTH),
							Math
									.min((leftPartText.length
											+ selPartText.length + MAX_LENGTH),
											range.endOffet));
		} else {
			selOffset.setOffset(leftPartText.length, leftPartText.length
					+ selPartText.length);
		}

		Controller.Log("getSelectionOffset() start, end = [" + selOffset.start
				+ ", " + selOffset.end + "]", 1);

		return selOffset;
	},
	
	getSelectedHtmlText : function(force) {
		var sel = window.getSelection(), range;
		if (!sel || 0 >= sel.rangeCount) {
			return undefined;
		}

		range = sel.getRangeAt(0);
		if (!range) {
			return undefined;
		}

		if (!range.collapsed) {
			var htmlFragment = range.cloneContents(), div = document
					.createElement('div'), selectedHtmlText;

			div.appendChild(htmlFragment);

			selectedHtmlText = div.outerHTML;
			Controller.Log(selectedHtmlText);
			if (div.innerText.length > 0) {
				return selectedHtmlText;
			} else {
				return undefined;
			}
		} else if (force == true) {
			var container = range.commonAncestorContainer,
				div = document.createElement('div'),
				textNode,
				selectedHtmlText;

			textNode = document.createTextNode(container.textContent);
			div.appendChild(textNode);

			selectedHtmlText = div.outerHTML;
			Controller.Log(selectedHtmlText);
			if (div.innerText.length > 0) {
				return selectedHtmlText;
			} else {
				return undefined;
			}
			return undefined;
		} else {
			return undefined;
		}
	},
	
	SelectionOffset : function(start, end) {
		this.start = start;
		this.end = end;
		this.afterText = true;

		this.setOffset = setOffset;

		function setOffset(start, end) {
			this.start = start;
			this.end = end;
		}

		this.setAfterText = setAfterText;
		function setAfterText(afterText) {
			this.afterText = afterText;
		}
	},

	Rect : function(left, top, right, bottom) {
		this.left = left;
		this.top = top;
		this.right = right;
		this.bottom = bottom;
		this.width = right - left;
		this.height = bottom - top;
	},

	SelectionInfo : function(startBoundRect, endBoundRect, /* optional */selectedText) {
		this.startBoundRect = startBoundRect;
		this.endBoundRect = endBoundRect;
		this.selectedText = selectedText;
		this.startOffset = -1;
		this.endOffset = -1;
		this.afterText = true;

		this.setSelectionOffset = function setSelectionOffset(start, end, afterText) {
			this.startOffset = start;
			this.endOffset = end;
			this.afterText = afterText;
		}

		if (startBoundRect == endBoundRect) {
			this.isCaret = true;
			this.isRange = false;
			this.selectionRect = new Selection.Rect(this.startBoundRect.left, this.startBoundRect.top, this.startBoundRect.right, this.startBoundRect.bottom);
		} else {
			this.isCaret = false;
			this.isRange = true;
			this.selectionRect = new Selection.Rect(this.startBoundRect.left, this.startBoundRect.top, this.endBoundRect.right, this.endBoundRect.bottom);
		}
	},

	onCommand : function(name, value) {
		document.execCommand(name, false, value);
	},

	onCopy : function(/* optional */isCut) {
		var objCopiedData = new Object();

		var sel = window.getSelection();
		if (!sel || 0 >= sel.rangeCount) {
			return objCopiedData;
		}

		var range = sel.getRangeAt(0);
		if (!range) {
			return objCopiedData;
		}

		if (!range.collapsed) {
			Controller.Log("copy() range.collapsed = " + range.collapsed
					+ ", isCut = " + isCut, 1);

			var htmlFragment = range.cloneContents();

			var span = document.createElement('span');
			span.appendChild(htmlFragment);
			
			this.onRemovePattern(span.children);

			objCopiedData.html = span.outerHTML;
			Controller.Log(objCopiedData.html);

			span.setAttribute("type", "hidden");
			document.body.appendChild(span);
			objCopiedData.text = span.innerText;
			document.body.removeChild(span);

			if (isCut) {
				document.execCommand('delete', false);
			} else {
				range.collapse(false);
				sel.removeAllRanges();
				sel.addRange(range);
			}
		}

		return objCopiedData;
	},

    getSelectionText : function() {
        var objCopiedData = new Object();

        var sel = window.getSelection();
        if (!sel || 0 >= sel.rangeCount) {
            return objCopiedData;
        }

        var range = sel.getRangeAt(0);
        if (!range) {
            return objCopiedData;
        }

        if (!range.collapsed) {
            Controller.Log("copy() range.collapsed = " + range.collapsed, 1);

            var htmlFragment = range.cloneContents();
            objCopiedData.text = htmlFragment.textContent;
        }

        return objCopiedData;
    },
	
	/**
	 * Pattern Match
	 * 1. get selected text.
	 * 2. check pattern in selected text.
	 * 3. update selection area
	 */
	onPatternMatching : function(callback) {
		var selection = window.getSelection(),
			selectedIndex = selection.focusOffset,
			startIndex = Math.max(selectedIndex - MAX_LENGTH, 0),
			lastIndex = Math.min(selectedIndex + MAX_LENGTH, selection.focusNode.length);

		jsonResult = JSON.stringify({
			"selectedText" : selection.focusNode.textContent,
			"selectedIndex" : selectedIndex,
			"startOffset" : startIndex,
			"endOffset" : lastIndex,
			"isCaret" : true
		});
		
		var patternResult = callback(jsonResult);

		if(patternResult) {
			var patternData = JSON.parse(patternResult);
	
			if(patternData.startOffset != -1 && patternData.endOffset != -1) {
				var range = document.createRange();
		
				range.collapse(true);
				range.setStart(selection.focusNode, patternData.startOffset);
				range.setEnd(selection.focusNode, patternData.endOffset);
				selection.removeAllRanges();
				selection.addRange(range);
			}
		}
	},
	
	onRemoveSelection : function() {
		var selection = window.getSelection();
		selection.removeAllRanges();
	},
	
	onRemovePattern : function(nodes) {
		for (var i = 0; i < nodes.length; i++) {
			var element = nodes[i], hasChild = element.children
					&& element.children.length > 0;
			if(hasChild) {
				this.onRemovePattern(element)
			} else {
				var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
				if (originalFontSize == -1) {
					element.style.fontSize = "";
				} else if (originalFontSize) {
					element.style.fontSize = originalFontSize;
				}
				
				var originalLineHeight = element.getAttribute(ORIGINAL_LINE_HEIGHT_ATTR);
				if (originalLineHeight) {
					element.style.lineHeight = originalLineHeight;
				} else {
					element.style.lineHeight = "";
				}
			}
		}
	},

//+Feature_SPen_Gesture_TextSelection
    onSelectBWStartAndEnd : function(startX, startY, endX, endY) {
        console.log("selectBWStartAndEnd startX = " + startX + ", startY = " + startY + ", endX = " + endX + ", endY = " + endY);

        var range = document.createRange();
        var startPosition = document.caretRangeFromPoint(startX/window.devicePixelRatio, startY/window.devicePixelRatio);
        var endPosition = document.caretRangeFromPoint(endX/window.devicePixelRatio, endY/window.devicePixelRatio);
        
        range.setStart(startPosition.startContainer, startPosition.startOffset);
        range.setEnd(endPosition.startContainer, endPosition.startOffset);

        var sel = window.getSelection();
        if( !sel || 0 >= sel.rangeCount ) {
            console.log("selectBWStartAndEnd() !sel OR 0 >= sel.rangeCount");
            return;
        }

        sel.removeAllRanges();
        sel.addRange(range);
    }
//-Feature_SPen_Gesture_TextSelection
};