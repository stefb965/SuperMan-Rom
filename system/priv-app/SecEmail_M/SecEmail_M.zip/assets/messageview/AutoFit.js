var root = this, AutoFit = root.AutoFit = {};

var ORIGINAL_FONT_ATTR = "original_font_attr",
	ORIGINAL_HEIGHT_ATTR = "original_height_attr",
	ORIGINAL_LEFT_ATTR = "original_left_attr",
	ORIGINAL_RIGHT_ATTR = "original_right_attr",
	ORIGINAL_TOP_ATTR = "original_top_attr",
	ORIGINAL_BOTTOM_ATTR = "original_bottom_attr",
	ORIGINAL_WIDTH_ATTR = "original_width_attr",
	ORIGINAL_LINE_HEIGHT_ATTR = "original_line_height_attr",
	SET_WIDTH_ATTR = "set_width_attr",
	STYLE_WIDTH_PERCENT = false;

var baseViewportWidth = 320,
	baseFontSize = 11,
	minimumFontSize = 7,
	fontScale = 1.0,
	secDivWidth = 0,
	loadedViewportWidth = 320,
	magicNumber = 0.00104,
	roundUnit = 2;

var applyNumberPattern = function(number) {
	return parseFloat(number.toFixed(roundUnit)) + magicNumber;
};

var getFontSize = function(fontSize) {
	var index = 0, fontString = String(fontSize), types = [ 'pt', 'px', 'em',
			'%' ], type = -1, numFontSize = i = 0;

	for (i = 0; i < types.length; i++) {
		if ((index = fontString.indexOf(types[i])) != -1) {
			type = i;
			break;
		}
	}

	numFontSize = fontString.substring(0, index);
	switch (type) {
	case 0:
		return numFontSize;
	case 1:
		return numFontSize * 0.75;
	case 2:
		return numFontSize * 11;
	case 3:
		return numFontSize * 11 / 100;
	default:
		var num = getFontSizeCSS(fontString);
		if (getFontSizeCSS(fontString) > 0) {
			return num;
		}
		return numFontSize;
	}
};

var getFontSizeCSS = function(fontString) {
	if (fontString == "xx-small") {
		return getFontNum(1);
	} else if (fontString == "x-small") {
		return getFontNum(2);
	} else if (fontString == "small") {
		return getFontNum(3);
	} else if (fontString == "medium") {
		return getFontNum(4);
	} else if (fontString == "large") {
		return getFontNum(5);
	} else if (fontString == "x-large") {
		return getFontNum(6);
	} else if (fontString == "xx-large") {
		return getFontNum(7);
	} else if (fontString == "-webkit-xxx-large") {
		return getFontNum(7); // '48px';
	}

	return -1;
}

var getMarginSize = function(marginSize) {
	var index = 0, marginString = String(marginSize), types = [ 'pt', 'px' ], type = -1, numSize = i = 0;

	for (i = 0; i < types.length; i++) {
		if ((index = marginString.indexOf(types[i])) != -1) {
			type = i;
			break;
		}
	}

	numSize = marginString.substring(0, index);
	switch (type) {
	case 0:
		return numSize * 1.33;
	case 1:
		return numSize;
	default:
		return numSize;
	}
};

var trim = function(value) {
	value = value.replace(/^\s+/, '');
	value = value.replace(/\s+$/g, '');
	value = value.replace(/\n/g, '');
	value = value.replace(/\r/g, '');
	return value;
};

var getFontNum = function(fontSize) {
	var fontNum = parseInt(fontSize);
	switch (fontNum) {
	case 1:
		return 7.5;// 6;
	case 2:
		return 9.75;// 10;
	case 3:
		return 12;// 13;
	case 4:
		return 13.5;// 16;
	case 5:
		return 18;// 26;
	case 6:
		return 24;// 36;
	case 7:
		return 36;// 40;
	default:
		return 12;// 13;
	}
};

var checkMagicNumber = function(number) {
	var temp = (number.toFixed(5) * 100000) % 1000;
	if (temp.toFixed() == 104)
		return 1;

	Controller.Log('checkMagicNumber() number = [' + number + '] temp = ['
			+ temp + ', ' + temp.toFixed(0) + ']', 2);
	return 0;
};

var adjustFontStyle = function(element, parentFontSize, scale) {
	var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
	if (originalFontSize == -1) {
		element.style.fontSize = "";
	} else if (originalFontSize) {
		element.style.fontSize = originalFontSize;
	}

	if (element.style.fontSize) {
		element.setAttribute(ORIGINAL_FONT_ATTR, element.style.fontSize);

		if (checkMagicNumber(parseFloat(getFontSize(element.style.fontSize))) == 1)
			element.style.fontSize = applyNumberPattern(getFontSize(element.style.fontSize) * scale) + 'pt';
		else
			element.style.fontSize = applyNumberPattern(Math.max(baseFontSize, getFontSize(element.style.fontSize)) * scale) + 'pt';
	} else {
		element.setAttribute(ORIGINAL_FONT_ATTR, -1);

		if (element.size && element.tagName.toLowerCase() == 'font') {
			var numSize = getFontNum(element.size);
			element.style.fontSize = applyNumberPattern(Math.max(baseFontSize, numSize) * scale) + 'pt';
		} else {
			if (parentFontSize)
				element.style.fontSize = applyNumberPattern(Math.max( baseFontSize, getFontSize(parentFontSize)) * scale) + 'pt';
			else
				element.style.fontSize = applyNumberPattern(Math.max( (baseFontSize * scale), minimumFontSize)) + 'pt';
		}
	}

	var originalLineHeight = element.getAttribute(ORIGINAL_LINE_HEIGHT_ATTR);
	if (originalLineHeight) {
		element.style.lineHeight = originalLineHeight;
	} else {
		element.style.lineHeight = "";
	}

	element.setAttribute(ORIGINAL_LINE_HEIGHT_ATTR, element.style.lineHeight);
	element.style['line-height'] = '140%';

	Controller.Log("adjustFontStyle() - node[" + element.nodeName + "], width["
			+ parseInt(element.style.width) + "], fontSize["
			+ parseFloat(element.style.fontSize) + "], scale[" + scale
			+ "] flag[0]", 2);
	return element.style.fontSize;
};

var adjustFontStyleForRotation = function(element, parentFontSize, scale) {
	var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
	if (originalFontSize == -1) {
		element.style.fontSize = "";
	} else if (originalFontSize) {
		element.style.fontSize = originalFontSize;
	}

	if (element.style.fontSize
			&& checkMagicNumber(parseFloat(getFontSize(element.style.fontSize))) == 1) {
		element.setAttribute(ORIGINAL_FONT_ATTR, element.style.fontSize);
		element.style.fontSize = applyNumberPattern(getFontSize(element.style.fontSize) * scale) + 'pt';
		Controller.Log("adjustFontStyleForRotation() - node["
				+ element.nodeName + "], width["
				+ parseInt(element.style.width) + "]," + " fontSize["
				+ parseFloat(element.style.fontSize) + "], scale[" + scale
				+ "] flag[1]", 2);
	} else {
		Controller.Log("adjustFontStyleForRotation() -  node["
				+ element.nodeName + "], width["
				+ parseInt(element.style.width) + "], fontSize["
				+ parseFloat(element.style.fontSize) + "], scale[" + scale
				+ "] flag[2]", 2);
	}
};

var adjustStyle = function(element, parentFontSize, parentWidth, scale) {
	var hasText = false, length = element.childNodes.length;
	for (var j = 0; j < length; j++) {
		if (element.childNodes[j].nodeType == 3) {
			var nodeValue = String(element.childNodes[j].nodeValue);
			nodeValue = trim(nodeValue);
			if (nodeValue.length > 0) {
				hasText = true;
				break;
			}
		}
	}

	if (element.nodeName == 'LI' || element.nodeName == 'DD') {
		// restore value
		var value = element.getAttribute(ORIGINAL_TOP_ATTR);
		if (value) {
			element.style['margin-top'] = value;
		}

		value = element.getAttribute(ORIGINAL_RIGHT_ATTR);
		if (value) {
			element.style['margin-right'] = value;
		}

		value = element.getAttribute(ORIGINAL_BOTTOM_ATTR);
		if (value) {
			element.style['margin-bottom'] = value;
		}

		var value = element.getAttribute(ORIGINAL_LEFT_ATTR);
		if (value) {
			element.style['margin-left'] = value;
		}

		var top = element.style['margin-top'] ? parseInt(element.style['margin-top'])
				: 0;
		var right = element.style['margin-right'] ? parseInt(element.style['margin-right'])
				: 0;
		var bottom = element.style['margin-bottom'] ? parseInt(element.style['margin-bottom'])
				: 0;
		var left = element.style['margin-left'] ? parseInt(element.style['margin-left'])
				: 0;

		if (top != 0) {
			element.setAttribute(ORIGINAL_TOP_ATTR, element.style['margin-top']);
			element.style['margin-top'] = applyNumberPattern(top * scale) + 'px';
		}

		if (right != 0) {
			element.setAttribute(ORIGINAL_RIGHT_ATTR, element.style['margin-right']);
			element.style['margin-right'] = applyNumberPattern(right * scale) + 'px';
		}
		if (bottom != 0) {
			element.setAttribute(ORIGINAL_BOTTOM_ATTR, element.style['margin-bottom']);
			element.style['margin-bottom'] = applyNumberPattern(bottom * scale) + 'px';
		}

		if (element.nodeName == 'LI') {
			element.setAttribute(ORIGINAL_LEFT_ATTR, element.style['margin-left']);
			element.style['margin-left'] = applyNumberPattern(((40 + left) * scale) - 40) + 'px';
		} else if (element.nodeName == 'DD') {
			element.setAttribute(ORIGINAL_LEFT_ATTR, element.style['margin-left']);
			left = element.style['margin-left'] ? parseInt(element.style['margin-left']) : 40;
			element.style['margin-left'] = applyNumberPattern(left * scale) + 'px';
		}
		
		if (parentWidth)
			adjustFontStyle(element, parentFontSize, scale);
		else
			adjustFontStyleForRotation(element, parentFontSize, scale);
	} else if (hasText) {
		var originalHeight = element.getAttribute(ORIGINAL_HEIGHT_ATTR);
		if (originalHeight == -1) {
			element.style.height = "";
		} else if (originalHeight) {
			element.style.height = originalHeight;
		}

		if (!element.style.height) {
			if (parentWidth)
				adjustFontStyle(element, parentFontSize, scale);
			else
				adjustFontStyleForRotation(element, parentFontSize, scale);
		} else {
			if (parentWidth) {
				element.setAttribute(ORIGINAL_HEIGHT_ATTR, element.style.height);
				var newFontSize = adjustFontStyle(element, parentFontSize,
						scale);
				element.style.height = Math.max(element.style.height,
						newFontSize);
			} else {
				adjustFontStyleForRotation(element, parentFontSize, scale);
			}
		}
	}
};

var addMagicNumber = function(element, parentFontSize) {
	var hasText = false, length = element.childNodes.length;
	for (var j = 0; j < length; j++) {
		if (element.childNodes[j].nodeType == 3) {
			var nodeValue = String(element.childNodes[j].nodeValue);
			nodeValue = trim(nodeValue);
			if (nodeValue.length > 0) {
				hasText = true;
				break;
			}
		}
	}
	if (hasText && !element.style.height) {
		var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
		if (originalFontSize == -1) {
			element.style.fontSize = "";
		} else if (originalFontSize) {
			element.style.fontSize = originalFontSize;
		}

		if (element.style.fontSize) {
			element.setAttribute(ORIGINAL_FONT_ATTR, element.style.fontSize);
			element.style.fontSize = applyNumberPattern(getFontSize(element.style.fontSize) * 1.0)
					+ 'pt';
		} else {
			element.setAttribute(ORIGINAL_FONT_ATTR, -1);
			if (element.size && element.tagName.toLowerCase() == 'font') {
				var numSize = getFontNum(element.size);
				element.style.fontSize = applyNumberPattern(numSize * 1.0)
						+ 'pt';
			} else {
				if (parentFontSize)
					element.style.fontSize = applyNumberPattern(getFontSize(parentFontSize) * 1.0)
							+ 'pt';
				else
					element.style.fontSize = applyNumberPattern(minimumFontSize * 1.0)
							+ 'pt';
			}
		}
	}
};

var addMagicNumberNodeTableTree = function(nodes, parentFontSize) {
	for (var i = 0; i < nodes.length; i++) {
		var element = nodes[i], hasChild = element.children
				&& element.children.length > 0;

		if (element.style['-webkit-text-size-adjust'])
			element.style['-webkit-text-size-adjust'] = 'none';
		else if (element.nodeName == 'TABLE' || element.nodeName == 'STYLE')
			continue;

		if (hasChild) {
			addMagicNumberNodeTableTree(element.children, parentFontSize);
		}
		addMagicNumber(element, parentFontSize);
	}
};

var checkNodeTree = function(nodes, parentFontSize, parentWidth,
		parentFontScale) {
	for (var i = 0; i < nodes.length; i++) {
		var element = nodes[i], hasChild = element.children
				&& element.children.length > 0;

		if (element.nodeName == 'TABLE') {
			var tableWidth = element.scrollWidth > 0 ? element.scrollWidth
					: element.offsetWidth > 0 ? element.offsetWidth
							: (element.style.width > 0 ? element.style.width
									: element.width),
 				tableMargin = 0;

			if (element.style.marginLeft) {
				tableMargin = parseInt(getMarginSize(element.style.marginLeft));
			}
			if (element.style.marginRight) {
				tableMargin += parseInt(getMarginSize(element.style.marginRight));
			}
			if (element.style.paddingLeft) {
				tableMargin += parseInt(getMarginSize(element.style.paddingLeft));
			}
			if (element.style.paddingRight) {
				tableMargin += parseInt(getMarginSize(element.style.paddingRight));
			}

			var tempParentWidth = parentWidth - tableMargin;
			var tableMinFontScale = tempParentWidth / parseFloat(tableWidth),
				tableFontScale = parentFontScale != null ? parentFontScale : Math.min(fontScale, tableMinFontScale);

			if (tableFontScale > 1.10) {
				var originalWidth = element.getAttribute(ORIGINAL_WIDTH_ATTR);
				if (originalWidth == -1) {
					element.style.width = "";
				} else if (originalWidth) {
					element.style.width = originalWidth;
				}

				if (tempParentWidth == null) {
					if (hasChild) {
						var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
						if (originalFontSize == -1) {
							element.style.fontSize = "";
						} else if (originalFontSize) {
							element.style.fontSize = originalFontSize;
						}
						
						var fontSize = element.style.fontSize ? element.style.fontSize : (parentFontSize ? parentFontSize : baseFontSize + 'px');
						checkNodeTableTree(element.children, fontSize, tempParentWidth, tableFontScale);
					}
					adjustStyle(element, parentFontSize, tempParentWidth, tableFontScale);
				} else {
					if (hasChild) {
						var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
						if (originalFontSize == -1) {
							element.style.fontSize = "";
						} else if (originalFontSize) {
							element.style.fontSize = originalFontSize;
						}
						
						var fontSize = element.style.fontSize ? element.style.fontSize : (parentFontSize ? parentFontSize : baseFontSize + 'px');
						checkNodeTableTree(element.children, fontSize, tempParentWidth, tableFontScale);
					}
					adjustStyle(element, parentFontSize, tempParentWidth, tableFontScale);

					// rollback
					if (element.scrollWidth > tempParentWidth) {
						tableFontScale = 1.0;
						if (hasChild) {
							var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
							if (originalFontSize == -1) {
								element.style.fontSize = "";
							} else if (originalFontSize) {
								element.style.fontSize = originalFontSize;
							}
							
							var fontSize = element.style.fontSize ? element.style.fontSize : (parentFontSize ? parentFontSize : baseFontSize + 'px');
							checkNodeTableTree(element.children, fontSize, tempParentWidth, tableFontScale);
						}
						adjustStyle(element, parentFontSize, tempParentWidth, tableFontScale);
					}

					if (tempParentWidth != null) {
						element.setAttribute(ORIGINAL_WIDTH_ATTR, element.style.width ? element.style.width : -1);
						if(STYLE_WIDTH_PERCENT) {
						    element.style.width = "100%";
						} else {
							if (element.style.width) {
								if (element.style.width != '100%') {
									element.style.width = tempParentWidth + 'px';
								}
							} else {
								element.style.width = tempParentWidth + 'px';
							}
						}
					}
				}
			} else {
//				if (hasChild) {
//					var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
//					if (originalFontSize == -1) {
//						element.style.fontSize = "";
//					} else if (originalFontSize) {
//						element.style.fontSize = originalFontSize;
//					}
//
//					var fontSize = element.style.fontSize ? element.style.fontSize
//							: (parentFontSize ? parentFontSize
//									: baseFontSize + 'px');
//					addMagicNumberNodeTableTree(element.children, fontSize);
//				}
//				addMagicNumber(element, parentFontSize);

				if (tempParentWidth != null) {
					element.setAttribute(ORIGINAL_WIDTH_ATTR, element.style.width ? element.style.width : -1);
					if(STYLE_WIDTH_PERCENT) {
					    element.style.width = "100%";
					} else {
						if (element.style.width) {
							if (element.style.width != '100%') {
								element.style.width = tempParentWidth + 'px';
							}
						} else {
							element.style.width = tempParentWidth + 'px';
						}
					}
				}
			}

			if (element.scrollWidth > tempParentWidth) {
				element.style.zoom = tempParentWidth / element.scrollWidth;
			}

            //Align-tag occur problem to the KMS mail is not shown.
            //It is resolved the other method, so this code blocked.
			/*
			if(element.align) {
				element.align = "";
			}
			*/
			continue;
		}
		/* block this code because change to percent.
		else if (element.nodeName == 'IMG' && element.style.display != 'none') {
		    var imageWidth = element.style.width ? element.style.width : element.width;
		    if (imageWidth == 0 || imageWidth == undefined) {
                element.style.maxWidth = parentWidth;
            }
		}
		*/

		if (element.style['-webkit-text-size-adjust'])
			element.style['-webkit-text-size-adjust'] = 'none';
		else if (element.style.width || element.nodeName == 'TABLE'
				|| element.nodeName == 'STYLE')
			continue;

		if (hasChild) {
			var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
			if (originalFontSize == -1) {
				element.style.fontSize = "";
			} else if (originalFontSize) {
				element.style.fontSize = originalFontSize;
			}

			var fontSize = parentFontSize;
			if (element.style.fontSize) {
				fontSize = element.style.fontSize;
			} else if (element.size && element.tagName.toLowerCase() == 'font') {
				fontSize = getFontNum(element.size) + "pt";
			}
			checkNodeTree(element.children, fontSize, parentWidth,
					parentFontScale);
		}
		adjustStyle(element, parentFontSize, parentWidth, fontScale);
	}
};

var checkNodeTableTree = function(nodes, parentFontSize, parentWidth,
		parentScale) {
	for (var i = 0; i < nodes.length; i++) {
		var element = nodes[i];
		var hasChild = element.children && element.children.length > 0;
		if (element.style['-webkit-text-size-adjust'])
			element.style['-webkit-text-size-adjust'] = 'none';
		else if (element.nodeName == 'TABLE' || element.nodeName == 'STYLE')
			continue;

		if (hasChild) {
			var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
			if (originalFontSize == -1) {
				element.style.fontSize = "";
			} else if (originalFontSize) {
				element.style.fontSize = originalFontSize;
			}

			var fontSize = element.style.fontSize ? element.style.fontSize
					: parentFontSize;
			checkNodeTableTree(element.children, fontSize, parentWidth,
					parentScale);
		}
		adjustStyle(element, parentFontSize, parentWidth, parentScale);
	}
};

var setZoom = function(viewportWidth) {
	var newViewport = Math.max(WIDE_VIEWPORT_WIDTH, WEBVIEW_WIDTH),
		orignalBody = document.getElementById("MessageViewBody"),
		orignalDiv = document.getElementById("MessageWebViewDiv"),
		orignalFooter = document.getElementById("conversation-footer-margin"),
		newZoom = newViewport / viewportWidth;

	// orignalBody.style.zoom = newZoom;
	orignalDiv.style.margin = "0px";
	orignalDiv.style.zoom = orignalDiv.style.zoom ? orignalDiv.style.zoom * newZoom : newZoom;
	orignalBody.style.marginLeft = (parseFloat(orignalBody.style.marginLeft) * parseFloat(newZoom)) + "px";
	orignalBody.style.marginRight = (parseFloat(orignalBody.style.marginRight) * parseFloat(newZoom)) + "px";
	orignalBody.style.width = newViewport - parseFloat(orignalBody.style.marginLeft) - parseFloat(orignalBody.style.marginRight) + "px";
	orignalFooter.style.height = (parseFloat(orignalFooter.style.height) * parseFloat(newZoom)) + "px";

}

var haveBlockquote = function() {
    var elements = document.getElementsByTagName("blockquote");
    return elements.length > 0 ? true : false;
}

AutoFit.onLoad = function(loadCallback, getViewportCallback, isPLMCSSStyle, fontSize) {
	Controller.Log("AutoFit.onLoad(" + DOC_BASE_URI + ") - start");
	// test
	/*
	var ww = document.body.offsetWidth < window.screen.width ? document.body.offsetWidth : window.screen.width;
	var mw = 480;
	var ratio = ww / mw;
	var metaViewport = document.getElementById("meta-viewport");
	if(ww < mw) {
		metaViewport.setAttribute('content', 'initial-scale=' + ratio + ', maximum-scale=' + (ratio * 2) + ', minimum-scale=' + (ratio / 2) + ', user-scalable=yes, width=' + ww);
	} else {
		metaViewport.setAttribute('content', 'initial-scale=1.0, maximum-scale=2, minimum-scale=1.0, user-scalable=yes, width=' + ww);
	}
    */
	var orignalBody = document.getElementById("MessageViewBody"),
    	orignalDiv = document.getElementById("MessageWebViewDiv"),
    	originalFooter = document.getElementById("conversation-footer-margin"),
    	width = 0,
    	newMargin = 0,
    	newFooterHeight = 0,
    	scaledFontSize = 0,
    	viewportWidth = 0,
    	newPadding = 0,
    	newWidth = 0,
    	baseFontScale = 1.0;

    // Zero GUI concept - base font size : 9pt
	switch (fontSize) {
		case 0 : {
			baseFontScale = 0.84;
		}
			break;
		case 1 : {
			baseFontScale = 0.9;
		}
			break;
		case 2 : {
			baseFontScale = 1.0;
		}
			break;
		case 3 : {
			baseFontScale = 1.16;
		}
			break;
		case 4 : {
			baseFontScale = 1.27;
		}
			break;
		case 5 : {
			baseFontScale = 1.37;
		}
			break;
		case 6 :
		case 7 :
		case 8 :
		case 9 :
		case 10 : {
			baseFontScale = 1.51;
		}
			break;
	}

    var defaultSize = 9 * 1.245; // 9 pt * change to ratio for set to 14dip
	baseFontSize = defaultSize * baseFontScale;

	/*
	orignalDiv.style.width = orignalDiv.scrollWidth = Math.max(orignalDiv.scrollWidth, 360);
	width = secDivWidth = parseInt(orignalDiv.style.width);
	*/
	
	baseViewportWidth = getViewportCallback();

	// for PLM style
	if (isPLMCSSStyle() || haveBlockquote()) {
		STYLE_WIDTH_PERCENT = true;
	}

	var orignalWidth = orignalDiv.style.width;
	if (orignalDiv.getAttribute(SET_WIDTH_ATTR)) {
		newWidth = orignalDiv.style.width;
		width = secDivWidth = parseInt(newWidth);
	} else {
		newWidth = Math.max(orignalDiv.scrollWidth, baseViewportWidth) + "px";
		orignalDiv.style.width = orignalDiv.scrollWidth = newWidth;
		width = secDivWidth = parseInt(newWidth);

		orignalDiv.setAttribute(SET_WIDTH_ATTR, 1);
	}

	var images = orignalDiv.getElementsByTagName("img");
	var imageWidth = 0, matcher;
	for (j = 0, imgCount = images.length; j < imgCount; j++) {
		image = images[j];
		var srcString = image.src;
		imageWidth = image.style.width ? image.style.width : image.width;
		var defaultSize = (image.width == 11 && image.height == 12); // default size

		if (imageWidth == 0 || imageWidth == undefined || defaultSize) {
		    /* block this code because change to percent.
			if (srcString.indexOf("attachmentid:") == 0
					|| srcString.indexOf("content://com.samsung.android.email.attach") == 0) {
				image.style.maxWidth = newWidth;
			} else {
				image.style.maxWidth = '100%';
			}
			*/
			image.style.maxWidth = '100%';
		}
	}

	loadedViewportWidth = baseViewportWidth;
	// fontScale = width / 360 * (360 / baseViewportWidth) * 1.0;
	fontScale = width / baseViewportWidth;
	// fontScale = Math.max((width / baseViewportWidth) / (WEBVIEW_WIDTH / width), 1.0);
	scaledFontSize = baseFontSize * fontScale;
	minimumFontSize = scaledFontSize > baseFontSize ? scaledFontSize : baseFontSize;

	Controller.Log("AutoFit.onLoad() - width = [" + width
			+ "] baseViewportWidth = [" + baseViewportWidth + "] baseFontSize["
			+ baseFontSize + "] fontScale[" + fontScale + "] scaledFontSize["
			+ scaledFontSize + "] minimumFontSize[" + minimumFontSize
			+ "] orignalDiv.style.width[" + orignalDiv.style.width
			+ "] orignalDiv.scrollWidth[" + orignalDiv.scrollWidth + "]", 1);

	var children = orignalDiv.children;

	checkNodeTree(children, null, width, null);

	adjustStyle(orignalDiv, null, width, fontScale);

	// rollback
	if (orignalDiv.scrollWidth > parseInt(newWidth)) {
		adjustStyle(orignalDiv, null, width, 1.0);
	}

	// change body & viewerport
	if (fontScale > 1.0) {
		newMargin = parseInt(parseInt(orignalBody.style.marginLeft) * fontScale) + "px";
		newFooterHeight = parseInt(parseInt(originalFooter.style.height) * fontScale) + "px";
		orignalBody.style.marginLeft = newMargin;
		orignalBody.style.marginRight = newMargin;
		originalFooter.style.height = newFooterHeight;
	} else {
		newMargin = parseInt(orignalBody.style.marginLeft) + "px";
	}

	orignalBody.style.width = newWidth;

	// viewport setup
	// viewportWidth = Math.min(WEBVIEW_WIDTH, (parseInt(newMargin) + parseInt(newWidth) + parseInt(newMargin)));
	viewportWidth = parseInt(newMargin) + parseInt(newWidth) + parseInt(newMargin);

	CONTENT_WIDTH = newWidth;
	var newViewport = Math.max(WIDE_VIEWPORT_WIDTH, WEBVIEW_WIDTH);
	if (viewportWidth <= newViewport) {
		var metaViewport = document.getElementById('meta-viewport');
		metaViewport.setAttribute('content', 'width=' + viewportWidth);
	} else {
		var metaViewport = document.getElementById('meta-viewport');
		metaViewport.setAttribute('content', 'width=' + newViewport);
	}

	CHANGE_VIEWPORT_WIDTH = false;
	if (viewportWidth > newViewport) {
		setZoom(viewportWidth);
		viewportWidth = newViewport;
		CHANGE_VIEWPORT_WIDTH = true;
	} else if (orignalDiv.scrollWidth > parseInt(newWidth)) {
		orignalDiv.style.zoom = parseInt(newWidth) / orignalDiv.scrollWidth;
	}

	// update message header, footer height
	var messageHeader = document.getElementById("mail-message-header"),
		messageFooter = document.getElementById("conversation-footer"),
		changeRatio = parseFloat(WEBVIEW_WIDTH) / parseFloat(viewportWidth);

	if(changeRatio == 1.0 && CHANGE_VIEWPORT_WIDTH) {
		changeRatio = 1 / DENSITY_RATIO;
	}

	if (messageHeader) {
		var headerHeight = parseFloat(messageHeader.style.height);
		messageHeader.style.height = parseFloat(headerHeight / changeRatio) + "px";
	}

	if (messageFooter) {
		var footerHeight = parseFloat(messageFooter.style.height);
		messageFooter.style.height = parseFloat(footerHeight / changeRatio) + "px";
	}

	// callback to webview
	loadCallback(viewportWidth, fontScale, minimumFontSize);

	Controller.Log("AutoFit.onLoad(" + DOC_BASE_URI + ") - end, viewportWidth[" + viewportWidth + "] newMargin[" + newMargin +"]");
};

AutoFit.onReLoad = function(loadCallback, getViewportCallback, isPLMCSSStyle) {
	var orignalBody = document.getElementById("MessageViewBody"),
		orignalDiv = document.getElementById("MessageWebViewDiv"),
		viewportWidth = 0,
		newWidth = 0,
		changeRatio = 1.0,
		scrollWidth = orignalBody.scrollWidth,
		margin = parseFloat(orignalBody.style.marginLeft) + "px",
		chagneSize = (scrollWidth - parseFloat(orignalBody.style.width) - parseFloat(margin) - parseFloat(margin)) > 1,
		newBodyWidth = scrollWidth - parseFloat(margin); // already include the left margin

	if (chagneSize) {
		Controller.Log("AutoFit.onReLoad(" + DOC_BASE_URI + ") - start");
		Controller.Log("AutoFit.onReLoad(" + DOC_BASE_URI + ") - scrollWidth["
				+ scrollWidth + "] orignalBody.style.width["
				+ orignalBody.style.width + "] leftMargin[" + margin + "]");

		changeRatio = parseFloat(orignalBody.style.width) / parseFloat(newBodyWidth);
		newWidth = newBodyWidth + "px";
		orignalBody.style.width = newWidth;

		// viewport setup
		// viewportWidth = Math.min(WEBVIEW_WIDTH, (parseInt(margin) + parseInt(newWidth) + parseInt(margin)));
		viewportWidth = parseInt(margin) + parseInt(newWidth) + parseInt(margin);

		CONTENT_WIDTH = newWidth;
		var newViewport = Math.max(WIDE_VIEWPORT_WIDTH, WEBVIEW_WIDTH);
		if (viewportWidth <= newViewport) {
			var metaViewport = document.getElementById('meta-viewport');
			metaViewport.setAttribute('content', 'width=' + viewportWidth);
		} else {
			var metaViewport = document.getElementById('meta-viewport');
			metaViewport.setAttribute('content', 'width=' + newViewport);
		}

		if (viewportWidth > newViewport) {
			setZoom(viewportWidth);
			viewportWidth = newViewport;
		}

		// update message header, footer height
		var messageHeader = document.getElementById("mail-message-header"),
			messageFooter = document.getElementById("conversation-footer");

		if (messageHeader) {
			var headerHeight = parseFloat(messageHeader.style.height);
			messageHeader.style.height = parseFloat(headerHeight / changeRatio) + "px";
		}

		if (messageFooter) {
        	var footerHeight = parseFloat(messageFooter.style.height);
        	messageFooter.style.height = parseFloat(footerHeight / changeRatio) + "px";
        }

		// callback to webview
		loadCallback(viewportWidth, fontScale, minimumFontSize);

		Controller.Log("AutoFit.onReLoad(" + DOC_BASE_URI + ") - end");
		return true;
	}

	return false;
};

AutoFit.onPatternUpdate = function() {
	var elements = document.getElementById("MessageWebViewDiv")
			.getElementsByTagName('a');
	for (var i = 0; i < elements.length; i++) {
		var element = elements[i];
		var originalFontSize = element.getAttribute(ORIGINAL_FONT_ATTR);
		var parentFontSize = element.parentNode.getAttribute(ORIGINAL_FONT_ATTR);
		if (originalFontSize == undefined && parentFontSize != undefined) {
			element.setAttribute(ORIGINAL_FONT_ATTR, -1);
			element.style.fontSize = element.parentNode.style.fontSize;

			element.setAttribute(ORIGINAL_LINE_HEIGHT_ATTR, "");
			element.style.lineHeight = element.parentNode.style.lineHeight;
		}
	}

	Controller.Log("AutoFit.onPatternUpdate(" + DOC_BASE_URI + ") - end");
};
