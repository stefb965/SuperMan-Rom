#!/system/bin/sh

log_xposed() {
  echo $1
  log -p i -t mount_xposed "$1"
}

loopsetup() {
  LOOPDEVICE=
  for DEV in $(ls /dev/block/loop*); do
    LS=$(losetup $DEV $1 2>/dev/null)
    if [ $? -eq 0 ]; then
      LOOPDEVICE=$DEV
      break
    fi
  done
}

if [ -z $(ls /xposed) ]; then
  if [ -f "/data/xposed.img" ]; then
    log_xposed "Xposed mount start"
    e2fsck -p /data/xposed.img
    chcon u:object_r:system_data_file:s0 /data/xposed.img
    chmod 0600 /data/xposed.img
    loopsetup /data/xposed.img
    if [ ! -z "$LOOPDEVICE" ]; then
      log_xposed "Mounting xposed.img to /xposed"
      mount -t ext4 -o rw,noatime $LOOPDEVICE /xposed
    fi
    log_xposed "Bind mount start"
    sh /xposed/bind_mount.sh
  fi
fi
