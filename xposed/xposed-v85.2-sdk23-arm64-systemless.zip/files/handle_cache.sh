#!/system/bin/sh

rm -f /su/xposed.prop
rm -rf /su/framework
rm -rf /su/lib64
find /su/lib ! -name "libsupol.so" -type f | xargs rm -f
find /su/bin -name "app_process*" -type f | xargs rm -f
find /su/bin -name "*oat*" -type f | xargs rm -f

umount /xposed
mv /cache/xposed.img /data/xposed.img
rm -f /su/su.d/handle_cache.sh
reboot