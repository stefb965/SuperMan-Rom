#!/system/bin/sh

log_xposed() {
  echo $1
  log -p i -t mount_xposed "$1"
}
