#!/system/bin/sh

LOGFILE=/cache/magisk.log
IMG=magisk.img

MOUNTPATH=/magisk/mounts
CACHEMOUNT=/cache/magisk/mounts
OVERLIST=$MOUNTPATH/lists/overwrite_list
DUMMLIST=$MOUNTPATH/lists/dummyitem_list
UPDATE=$MOUNTPATH/lists/update
OVERPATH=/cache/overwrite
DUMMPATH=/cache/dummyitem

# Use the included busybox to do everything in all scripts for maximum compatibility
# We also do so because we rely on the option "-c" for cp (reserve contexts)
export PATH="/data/busybox:$PATH"

log_print() {
  echo $1
  echo $1 >> $LOGFILE
  log -p i -t Magisk "$1"
}

mktouch() {
  mkdir -p ${1%/*}
  touch $1
}

unblock() {
  mktouch /cache/unblock/$1
  exit
}

run_scripts() {
  chmod 750 $1/* 2>/dev/null
  for SCRIPT in $1/* ; do
    if [ -f "$SCRIPT" ]; then
      log_print "$2: $SCRIPT"
      $SCRIPT
    fi
  done
}

loopsetup() {
  LOOPDEVICE=
  for DEV in $(ls /dev/block/loop*); do
    if [ `losetup $DEV $1 >/dev/null 2>&1; echo $?` -eq 0 ]; then
      LOOPDEVICE=$DEV
      break
    fi
  done
}

target_size_check() {
  e2fsck -p -f $1
  curBlocks=`e2fsck -n $1 2>/dev/null | cut -d, -f3 | cut -d\  -f2`;
  curUsedM=$((`echo "$curBlocks" | cut -d/ -f1` * 4 / 1024));
  curSizeM=$((`echo "$curBlocks" | cut -d/ -f2` * 4 / 1024));
  curFreeM=$((curSizeM - curUsedM));
}

remove_dummy() {
  while IFS= read -r TARGET || [ -n "$TARGET" ]; do
    rm -rf $1$TARGET
  done < $1/lists/dummyitem_list
  rm -f $1/lists/dummyitem_list
  rmdir $(find $1/system/* -type d -depth) 2>/dev/null
}

travel() {
  SYSPATH=${1#$MOUNTPATH}
  if [ -f "$1/.replace" ]; then
    mktouch $OVERPATH$SYSPATH
  else
    for ITEM in $1/* ; do
      if [ $ITEM = "$MOUNTPATH/system/*" ]; then return; fi
      TARGET=${ITEM#$MOUNTPATH}
      if [ -e "$TARGET" ]; then
        if [ -d "$ITEM" ]; then
          # It's an directory, travel deeper
          (travel $ITEM)
        else
          # This file exists in system
          mktouch $OVERPATH$TARGET
        fi
      else
        # Found a new file, create dummy items recursively
        rm -rf $OVERPATH$SYSPATH
        if [ $SYSPATH = "/system" ]; then rm -rf $ITEM ; fi
        (travel_mirror_dir $SYSPATH)
        mktouch $OVERPATH$SYSPATH
        # Don't proceed more as we will mount the whole directory
        return
      fi
    done
  fi
}

travel_mirror_dir() {
  if [ ! -f "$MOUNTPATH$1/.replace" ]; then
    for ITEM in $1/* ; do
      TARGET=$MOUNTPATH$ITEM
      # Item do not exist, create dummy or copy symlinks
      if [ ! -e "$TARGET" ]; then
        if [ -d "$ITEM" ]; then
          mkdir -p $TARGET
          mktouch $DUMMPATH$ITEM
        elif [ -L "$ITEM" ]; then
          cp -afc $ITEM $TARGET
        else
          touch $TARGET
          mktouch $DUMMPATH$ITEM
        fi
      # Item exists, check if it's directory and recursive travel
      else
        if [ -d "$ITEM" ]; then
          (travel_mirror_dir $ITEM)
        fi
      fi
    done
  fi
}

construct_lists() {
  # First do cleanups (remove dummy items)
  remove_dummy $MOUNTPATH
  # Travel through the directory
  (travel $MOUNTPATH/system)
  # linker(64), t*box, and app_process* are required if we need to bind mount the whole bin folder
  if [ -f "$OVERPATH/system/bin" ]; then
    rm -f $DUMMPATH/system/bin/linker* $DUMMPATH/system/bin/t*box $DUMMPATH/system/bin/app_process*
    cp -afc /system/bin/linker* $MOUNTPATH/system/bin/
    cp -afc /system/bin/t*box $MOUNTPATH/system/bin/
    cp -afc /system/bin/app_process* $MOUNTPATH/system/bin/
  fi
  # collect_list
  rm -f $OVERLIST $DUMMLIST $UPDATE
  find $OVERPATH -type f 2>/dev/null | while read ITEM ; do
    TARGET=${ITEM#$OVERPATH}
    echo $TARGET >> $OVERLIST
  done
  find $DUMMPATH -type f 2>/dev/null | while read ITEM ; do
    TARGET=${ITEM#$DUMMPATH}
    echo $TARGET >> $DUMMLIST
  done
  rm -rf $OVERPATH $DUMMPATH
}

bind_mount() {
  if [ -e "$2" ]; then
    mount -o bind $1 $2
    if [ "$?" -eq "0" ]; then log_print "Magic Mount: $1 -> $2";
    else log_print "Fail: $1 -> $2"; fi
  else
    log_print "$2 do not exist!" 
  fi
}

bind_system() {
  if [ -f "$UPDATE" ]; then
    log_print "Constructing lists to bind mount"
    construct_lists
  fi
  if [ -f "$OVERLIST" ]; then
    log_print "Bind mount items to system"

    # Bind mount items
    while IFS= read -r TARGET || [ -n "$TARGET" ]; do
      ORIG=$MOUNTPATH$TARGET
      bind_mount $ORIG $TARGET
    done < $OVERLIST

    log_print "Bind mount system mirror"

    # Mount system mirror
    bind_mount /system $MOUNTPATH/mirror

    log_print "Bind mount mirror items back to dummies"

    # Bind mount mirrors files back
    while IFS= read -r TARGET || [ -n "$TARGET" ]; do
      ORIG=$MOUNTPATH$TARGET
      ORIG=${ORIG/system/mirror}
      bind_mount $ORIG $TARGET
    done < $DUMMLIST
  fi
}

case $1 in
  post-fs )
    # Temporary switch to permissive for maximum compatibility
    echo 0 > /sys/fs/selinux/enforce
    mv $LOGFILE /cache/last_magisk.log
    log_print "Magisk post-fs mode running..."

    find $CACHEMOUNT/system -type f 2>/dev/null | while read ITEM ; do
      TARGET=${ITEM#$CACHEMOUNT}
      bind_mount $ITEM $TARGET
    done

    run_scripts /cache/magisk/post-fs.d post-fs.d
    unblock post-fs

    ;;
  post-fs-data )

    if [ `mount | grep " /data " >/dev/null 2>&1; echo $?` -ne 0 ]; then
      # /data not mounted yet, we will be called again later
      unblock post-fs-data
    fi

    if [ `mount | grep " /data " | grep "tmpfs" >/dev/null 2>&1; echo $?` -eq 0 ]; then
      # /data not mounted yet, we will be called again later
      unblock post-fs-data
    fi
    if [ "$(getprop magisk.post-fs-data)" -eq "0" ]; then
      log_print "Magisk post-fs-data mode running..."

      if [ -f "/cache/busybox" ]; then
        rm -rf /data/busybox
        mkdir -p /data/busybox
        mv /cache/busybox /data/busybox/busybox
        chmod 755 /data/busybox/busybox
        /data/busybox/busybox --install -s /data/busybox
        # Prevent issues
        rm -f /data/busybox/su
      fi

      mv /cache/stock_boot* /data/ 2>/dev/null

      mv /cache/Magisk.apk /data/Magisk.apk 2>/dev/null

      if [ -f "/data/Magisk.apk" ]; then
        
        APKPATH=com.topjohnwu.magisk-1
        for i in `ls /data/app | grep com.topjohnwu.magisk-`; do
          if [ `cat /data/system/packages.xml | grep $i >/dev/null 2>&1; echo $?` -eq 0 ]; then
            APKPATH=$i
            break;
          fi
        done

        rm -rf /data/app/com.topjohnwu.magisk*

        mkdir -p /data/app/$APKPATH
        chown 1000.1000 /data/app/$APKPATH
        chmod 0755 /data/app/$APKPATH
        chcon u:object_r:apk_data_file:s0 /data/app/$APKPATH

        mv /data/Magisk.apk /data/app/$APKPATH/base.apk
        chown 1000.1000 /data/app/$APKPATH/base.apk
        chmod 0644 /data/app/$APKPATH/base.apk
        chcon u:object_r:apk_data_file:s0 /data/app/$APKPATH/base.apk
      fi

      # Handle /cache image
      if [ -f "/cache/$IMG" ]; then
        log_print "/cache/$IMG found"

        if [ -f "/data/$IMG" ]; then

          log_print "/data/$IMG found, attempt to merge"

          # Handle large images from cache
          target_size_check /cache/$IMG
          CACHEUSED=$curUsedM
          target_size_check /data/$IMG
          if [ "$CACHEUSED" -gt "$curFreeM" ]; then
            NEWDATASIZE=$((((CACHEUSED + curUsedM) / 32 + 2) * 32))
            log_print "Expanding $IMG to $NEWDATASIZE M..."
            resize2fs /data/$IMG "$NEWDATASIZE"M
          fi

          # Start merging

          mkdir /cache/data_img
          mkdir /cache/cache_img

          # setup loop devices

          loopsetup /data/$IMG
          LOOPDATA=$LOOPDEVICE
          log_print "$LOOPDATA /data/$IMG"

          loopsetup /cache/$IMG
          LOOPCACHE=$LOOPDEVICE
          log_print "$LOOPCACHE /cache/$IMG"

          if [ ! -z "$LOOPDATA" ]; then
            if [ ! -z "$LOOPCACHE" ]; then
              # if loop devices have been setup, mount images
              OK=true

              if [ `mount -t ext4 -o rw,noatime $LOOPDATA /cache/data_img >/dev/null 2>&1; echo $?` -ne 0 ]; then
                OK=false
              fi

              if [ `mount -t ext4 -o rw,noatime $LOOPCACHE /cache/cache_img >/dev/null 2>&1; echo $?` -ne 0 ]; then
                OK=false
              fi

              if ($OK); then
                # Before merging, we have to clean up if mounts need to update
                if [ -f "/cache/cache_img/mounts/lists/update" ]; then
                  remove_dummy /cache/data_img/mounts
                fi

                # Custom cache merge actions, most likely to be some cleanup scripts
                run_scripts /cache/magisk/cache_merge.d cache_merge.d

                # Merge (will reserve selinux contexts)
                if [ `cp -afc /cache/cache_img/. /cache/data_img >/dev/null 2>&1; echo $?` -eq 0 ]; then
                  log_print "Merge complete"
                fi
              fi

              umount /cache/data_img
              umount /cache/cache_img
            fi
          fi

          losetup -d $LOOPDATA
          losetup -d $LOOPCACHE

          rmdir /cache/data_img
          rmdir /cache/cache_img
        else 
          log_print "Moving /cache/$IMG to /data/$IMG "
          mv /cache/$IMG /data/$IMG
        fi
        rm -f /cache/$IMG
        # Only run once, remove after executing
        rm -rf /cache/magisk/cache_merge.d/*
      fi

      # Shrink the image if possible
      target_size_check /data/$IMG
      NEWDATASIZE=$(((curUsedM / 32 + 2) * 32))
      if [ "$curSizeM" -gt "$NEWDATASIZE" ]; then
        log_print "Shrinking $IMG to $NEWDATASIZE M..."
        resize2fs /data/$IMG "$NEWDATASIZE"M
      fi

      # Mount /data image
      if [ `cat /proc/mounts | grep /magisk >/dev/null 2>&1; echo $?` -ne 0 ]; then
        loopsetup /data/$IMG
        if [ ! -z "$LOOPDEVICE" ]; then
          mount -t ext4 -o rw,noatime $LOOPDEVICE /magisk
        fi
      fi

      if [ `cat /proc/mounts | grep /magisk >/dev/null 2>&1; echo $?` -ne 0 ]; then
        log_print "All mounts failed, nothing to do :("
        unblock post-fs-data
      fi

      mv /cache/magisk/post-fs-data.d/* /magisk/post-fs-data.d/ 2>/dev/null

      # Always do Magic Mount first
      bind_system

      # Then do external job
      run_scripts /magisk/post-fs-data.d post-fs-data.d

      # Bind hosts for Adblock apps
      if [ ! -f "/magisk/hosts" ]; then
        cp -afc /system/etc/hosts /magisk/hosts
      fi
      mount -o bind /magisk/hosts /system/etc/hosts
      
      setprop magisk.post-fs-data 1
      unblock post-fs-data
    fi

    ;;
  service )
    log_print "Magisk late_start service mode running..."
    mv /cache/magisk/service.d/* /magisk/service.d/ 2>/dev/null
    run_scripts /magisk/service.d service.d
    if [ ! -f "/magisk/post-fs-data.d/permissive" ]; then
      echo 1 > /sys/fs/selinux/enforce
    fi
    ;;

  unroot )
    TIMEOUT=$(getprop magisk.timeout)
    if [ -z "$TIMEOUT"]; then
      # Default to 5 mins
      TIMEOUT=300
    fi
    log_print "Temp unroot for $TIMEOUT seconds"

    # Kill all root shell
    ps -Z | grep u:r:su:s0 | grep -w sh | grep -v u:r:adbd:s0 | while read PS ; do
      set $PS
      log_print "Killing PID: $2"
      kill -9 $2
    done

    # Kill all root process
    ps -Z | grep u:r:su:s0 | grep -v u:r:adbd:s0 | while read PS ; do
      set $PS
      log_print "Killing PID: $2"
      kill -9 $2
    done

    # Kill any possible su calls
    killall su
    # Finally unmount root from system
    umount -l /system/xbin

    sleep $TIMEOUT
    # Setup root after timeout
    mount -o bind /magisk/phh/xbin /system/xbin
    setprop magisk.phhsu 1
    ;;
esac
